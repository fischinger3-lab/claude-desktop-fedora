#!/usr/bin/env python3
"""Install our AppImage, original icon and claude:// handler for this user."""
import os
from pathlib import Path
import shutil
import subprocess
import sys


def desktop_quote(value):
    # Desktop Entry Exec quoting, including literal percent field markers.
    value = str(value).replace('%', '%%')
    for character in ('\\', '"', '`', '$'):
        value = value.replace(character, '\\' + character)
    return '"' + value.replace('\\', '\\\\') + '"'


def install(appimage, icon):
    appimage, icon = Path(appimage).resolve(), Path(icon).resolve()
    if not appimage.is_file() or not icon.is_file():
        raise ValueError('AppImage und claude-desktop.png müssen vorhanden sein.')
    if icon.read_bytes()[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('Ungültiges Claude-PNG-Icon.')
    home = Path.home()
    data = Path(os.environ.get('XDG_DATA_HOME', home / '.local/share'))
    target = home / '.local/opt/claude-desktop/Claude.AppImage'
    installed_icon = data / 'icons/hicolor/256x256/apps/claude-desktop-fedora.png'
    desktop = data / 'applications/claude-fedora-appimage.desktop'
    for path in (target, installed_icon, desktop):
        path.parent.mkdir(parents=True, exist_ok=True)
    if appimage != target:
        shutil.copyfile(appimage, target)
    target.chmod(0o755)
    shutil.copyfile(icon, installed_icon)
    installed_icon.chmod(0o644)
    desktop.write_text('[Desktop Entry]\nType=Application\nName=Claude\n'
        'Comment=Claude Desktop für Fedora\n'
        f'Exec={desktop_quote(target)} %u\nIcon={installed_icon}\n'
        'Terminal=false\nCategories=Office;\nMimeType=x-scheme-handler/claude;\n'
        'StartupWMClass=com.anthropic.Claude\n')
    desktop.chmod(0o644)
    if shutil.which('update-desktop-database'):
        subprocess.run(['update-desktop-database', str(desktop.parent)], check=True)
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', desktop.name, 'x-scheme-handler/claude'], check=True)
    print(f'Claude mit Icon und Anmeldezuordnung installiert: {target}')


if __name__ == '__main__':
    if os.geteuid() == 0:
        sys.exit('Bitte ohne sudo als normaler Benutzer starten.')
    if len(sys.argv) != 2:
        sys.exit('Aufruf: python3 install-appimage.py /pfad/zu/Claude.AppImage')
    install(sys.argv[1], Path(__file__).resolve().parent / 'claude-desktop.png')
