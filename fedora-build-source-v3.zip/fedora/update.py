#!/usr/bin/env python3
"""Resolve official amd64 Claude; download and validate before packaging."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import urllib.error
import urllib.request

BASE = 'https://downloads.claude.ai/claude-desktop/apt/stable/'
INDEX = BASE + 'dists/stable/main/binary-amd64/Packages'


def newest_package(text):
    packages = []
    for block in text.split('\n\n'):
        fields = dict(line.split(': ', 1) for line in block.splitlines()
                      if ': ' in line and not line.startswith((' ', '\t')))
        if fields.get('Package') != 'claude-desktop' or fields.get('Architecture') != 'amd64':
            continue
        version = fields.get('Version', '')
        filename = fields.get('Filename', '')
        sha = fields.get('SHA256', '')
        if not re.fullmatch(r'\d+(?:\.\d+)+', version):
            raise ValueError('Unsupported official version; manual review needed')
        if not re.fullmatch(r'pool/main/c/claude-desktop/claude-desktop_[0-9.]+_amd64\.deb', filename):
            raise ValueError('Unexpected official artifact path')
        if filename.rsplit('/', 1)[-1] != f'claude-desktop_{version}_amd64.deb':
            raise ValueError('Version and artifact filename disagree')
        if not re.fullmatch(r'[a-f0-9]{64}', sha):
            raise ValueError('Missing or invalid official SHA256')
        size = int(fields['Size'])
        if size <= 0:
            raise ValueError('Invalid official artifact size')
        packages.append((tuple(map(int, version.split('.'))), version, filename, sha, size))
    if not packages:
        raise ValueError('No valid official amd64 Claude package found')
    return max(packages)


def github_json(path):
    request = urllib.request.Request('https://api.github.com/' + path,
        headers={'Authorization': 'Bearer ' + os.environ['GH_TOKEN'],
                 'Accept': 'application/vnd.github+json', 'User-Agent': 'claude-fedora-builder'})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        if error.code == 404:
            return None
        raise


def main():
    with urllib.request.urlopen(INDEX, timeout=60) as response:
        _, version, filename, sha, size = newest_package(response.read().decode())
    repo = os.environ['GITHUB_REPOSITORY']
    tag = f'v{version}-fedora.3'
    release = github_json(f'repos/{repo}/releases/tags/{tag}')
    build = not release or release.get('draft', False)
    if release and not release.get('draft', False):
        names = {asset['name'] for asset in release['assets']}
        if not any(n.endswith('.rpm') for n in names) or not any(n.endswith('.AppImage') for n in names) or not {'SHA256SUMS', 'install-appimage.py', 'claude-desktop.png'}.issubset(names):
            raise ValueError('Existing published release is incomplete; manual review needed')
    with open(os.environ['GITHUB_OUTPUT'], 'a') as output:
        output.write(f'version={version}\ntag={tag}\nbuild={str(build).lower()}\n')
    print(f'Official Claude {version}; tag {tag}; build needed: {build}')
    if not build:
        return
    target = Path.cwd() / 'official.deb'
    digest = hashlib.sha256()
    actual_size = 0
    with urllib.request.urlopen(BASE + filename, timeout=180) as response, target.open('wb') as dest:
        while chunk := response.read(1024 * 1024):
            digest.update(chunk)
            actual_size += len(chunk)
            dest.write(chunk)
    if digest.hexdigest() != sha or actual_size != size:
        target.unlink(missing_ok=True)
        raise ValueError('Official package checksum or size mismatch')
    # Update the extracted source only. GitHub Actions does not push code or tags
    # until build and verification succeed; the release records the exact input.
    pin = Path('scripts/setup/official-deb.sh')
    text = pin.read_text()
    for key, value in {'OFFICIAL_DEB_VERSION': version,
                       'OFFICIAL_DEB_POOL_AMD64': filename,
                       'OFFICIAL_DEB_SHA256_AMD64': sha}.items():
        text, count = re.subn(r'^' + key + r'=.*$', key + "='" + value + "'", text, flags=re.M)
        if count != 1:
            raise ValueError('Official pin structure changed')
    pin.write_text(text)
    Path('release-notes.md').write_text(
        f'Claude Desktop {version} für Fedora 44 x86_64.\n\n'
        f'Originalquelle: {BASE + filename}\n\nSHA-256 der Originaldatei: `{sha}`\n\n'
        'Inoffizielles Repackaging; RPM und AppImage aus derselben geprüften Quelle. '
        'Automatische Paket- und Strukturtests bestanden. '
        'GUI-Anmeldung und Cowork sind nicht durch diese Tests abgedeckt.\n\n'
        'RPM installieren: `sudo dnf install ./claude-desktop-unofficial-*.rpm`\n\n'
        'AppImage mit Icon installieren: PNG und install-appimage.py aus diesem Release neben die AppImage-Datei laden, dann `python3 install-appimage.py ./claude-desktop-unofficial-*.AppImage`.\n\n'
        'Anmeldezuordnung nach Wechsel vom AppImage: '
        '`xdg-mime default claude-desktop-unofficial.desktop x-scheme-handler/claude`\n')


if __name__ == '__main__':
    main()
