import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('installer', Path(__file__).with_name('install-appimage.py'))
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


class IconInstallTests(unittest.TestCase):
    def test_installs_icon_and_replaces_old_entry(self):
        with tempfile.TemporaryDirectory(prefix='claude icon ') as temp:
            root = Path(temp)
            source = root / 'source.AppImage'
            source.write_bytes(b'test-appimage')
            icon = root / 'claude.png'
            icon.write_bytes(b'\x89PNG\r\n\x1a\nicon-fixture')
            data = root / 'data'
            desktop = data / 'applications/claude-fedora-appimage.desktop'
            desktop.parent.mkdir(parents=True)
            desktop.write_text('[Desktop Entry]\nName=Claude\n')
            with patch.dict(os.environ, {'HOME': str(root), 'XDG_DATA_HOME': str(data)}), \
                 patch.object(installer.subprocess, 'run') as run:
                installer.install(source, icon)
                self.assertIn('Icon=' + str(data / 'icons/hicolor/256x256/apps/claude-desktop-fedora.png'), desktop.read_text())
                self.assertIn('MimeType=x-scheme-handler/claude;', desktop.read_text())
                self.assertEqual((root / '.local/opt/claude-desktop/Claude.AppImage').read_bytes(), b'test-appimage')
            self.assertEqual(subprocess.run(['desktop-file-validate', str(desktop)]).returncode, 0)

    def test_rejects_invalid_icon_before_writing(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / 'source.AppImage'; source.write_bytes(b'test')
            icon = root / 'bad.png'; icon.write_text('not a PNG')
            with self.assertRaises(ValueError): installer.install(source, icon)


if __name__ == '__main__': unittest.main()
