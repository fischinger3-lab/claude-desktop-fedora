# shellcheck shell=bash
#===============================================================================
# Linux tray icon env override: honor CLAUDE_TRAY_USE_DARK_ICON.
#
# Upstream already ships TrayIconLinux.png (dark glyph, light panels)
# and TrayIconLinux-Dark.png (light glyph, dark panels) and picks
# between them from nativeTheme.shouldUseDarkColors plus a GNOME
# desktop check — its DE detector only ever returns kde/gnome/other,
# so Cinnamon falls to "other". Cinnamon often uses a dark panel
# while GTK still reports a light colour scheme, so the black icon
# lands on a dark gray tray (#604). The launcher probes that case and
# exports CLAUDE_TRAY_USE_DARK_ICON=1; this patch threads the flag
# into the existing ternary without replacing upstream's icons.
#
# Tri-state: "1" forces TrayIconLinux-Dark.png, "0" forces
# TrayIconLinux.png (overriding the GNOME check and
# shouldUseDarkColors), anything else leaves upstream's selection
# untouched. The env read lands inside the selector, which re-runs on
# nativeTheme "updated", so the flag survives theme-change rebuilds.
#
# An anchor miss fails the build: shipping without this patch leaves
# CLAUDE_TRAY_USE_DARK_ICON inert while the docs and launcher still
# advertise it (#429 failure class, and check-claude-version auto-tags
# releases with no human in the loop). The hard fail doubles as the
# retirement tripwire for when upstream teaches its own DE detector
# about Cinnamon (filed as anthropics/claude-code#77170).
#
# Interim fix pending upstream; this is not a net-new feature.
#
# Sourced by: build.sh
# Sourced globals: (none — resolves its own file via _resolve_anchor_file,
#   defined in app-asar.sh)
# Modifies globals: (none)
#===============================================================================

patch_tray_icon_env_override() {
	echo 'Patching Linux tray icon selection (CLAUDE_TRAY_USE_DARK_ICON)...'

	# On 1.26832.0 this anchor sits in index.js itself rather than in any
	# chunk — the entry file stopped being a stub and now carries real
	# code (#820). Resolving by anchor rather than by filename is what
	# makes that a non-event.
	local index_js
	# Anchored on the adjacent icon-literal pair rather than on the
	# ternary condition: the patch rewrites the condition but re-emits
	# these two literals verbatim, so resolution still works on a re-run.
	index_js=$(_resolve_anchor_file 'tray icon literals' \
		'[`"'"'"']TrayIconLinux-Dark\.png[`"'"'"']\s*:\s*[`"'"'"']TrayIconLinux\.png[`"'"'"']') \
		|| return 1

	# Anchored on the two stable icon literals (developer strings
	# survive minification); the DE-detector and electron identifiers
	# are captured, not hardcoded — they change every release
	# (docs/learnings/patching-minified-js.md). Whitespace-tolerant so
	# the same anchor matches beautified reference bundles.
	if INDEX_JS="$index_js" node << 'TRAY_ICON_PATCH'
const fs = require('fs');
const indexJs = process.env.INDEX_JS;
let code = fs.readFileSync(indexJs, 'utf8');

const flag = 'process.env.CLAUDE_TRAY_USE_DARK_ICON';

const applied = flag + '==="1"||' + flag + '!=="0"&&(';

// The matched condition must start at an expression boundary. In
// particular, never leave a member access or an unhandled || prefix behind.
const spliceSafe = index => {
    const prefix = code.slice(0, index).trimEnd();
    return prefix === '' || /(?:[=(,;:?{[]|=>)$/.test(prefix) ||
        /(?:^|[^\w$.])return$/.test(prefix);
};

const identifier = String.raw`[a-zA-Z_$][\w$]*`;
const chain = String.raw`${identifier}(?:\.${identifier})*`;
const call = String.raw`(?:\(0,\s*${chain}\)|${chain})\(\)`;
const or = String.raw`\s*\|\|\s*`;
const gnome = String.raw`\s*===\s*(?:"gnome"|'gnome'|\x60gnome\x60)`;
const legacy = String.raw`(?:${identifier}${or})?${call}${gnome}${or}${chain}\.nativeTheme\.shouldUseDarkColors`;
// 6.28899.2 destructures safeIcon, linuxFlavor and theme into local
// bindings in the selector. Retain the entire condition, including safeIcon.
const modern = String.raw`${identifier}${or}${call}${gnome}${or}${identifier}\.shouldUseDarkColors`;
const icons = String.raw`\s*\?\s*(?:"TrayIconLinux-Dark\.png"|'TrayIconLinux-Dark\.png'|\x60TrayIconLinux-Dark\.png\x60)\s*:\s*(?:"TrayIconLinux\.png"|'TrayIconLinux\.png'|\x60TrayIconLinux\.png\x60)`;
const escapeRegex = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const condition = `(?:${legacy}|${modern})`;
const pattern = new RegExp(
    `(${condition})${icons}`, 'g');
const patchedPattern = new RegExp(
    `${escapeRegex(applied)}${condition}\\)${icons}`, 'g');

const patched = [...code.matchAll(patchedPattern)];
const matches = [...code.matchAll(pattern)];
if (patched.length === 1 && matches.length === 0 && spliceSafe(patched[0].index)) {
    console.log('  Tray icon env override already applied');
    process.exit(0);
}
if (code.includes(applied)) {
    console.log('  WARNING: the injected tri-state is ambiguous or the bundle is corrupt. Re-extract a pristine asar.');
    process.exit(1);
}
if (matches.length !== 1) {
    console.log('  WARNING: expected exactly 1 TrayIconLinux ternary, found ' + matches.length);
    process.exit(1);
}

const match = matches[0];
if (!spliceSafe(match.index)) {
    console.log('  WARNING: TrayIconLinux ternary matched mid-expression; inspect the upstream selector.');
    process.exit(1);
}
const original = match[1];
const replacement = applied + original + ')' + match[0].slice(original.length);
code = code.slice(0, match.index) + replacement + code.slice(match.index + match[0].length);
fs.writeFileSync(indexJs, code);
console.log('  Tray icon selector now honors CLAUDE_TRAY_USE_DARK_ICON (1=dark-panel, 0=plain)');
TRAY_ICON_PATCH
	then
		echo 'Tray icon env override applied'
	else
		echo 'ERROR: tray icon env-override patch failed. Without it,' \
			'CLAUDE_TRAY_USE_DARK_ICON is inert and Cinnamon dark panels' \
			'keep the invisible black tray glyph (#604). Update the' \
			'anchor in scripts/patches/tray-icon-selection.sh against' \
			'the new bundle — or, if upstream taught its DE detector' \
			'about Cinnamon (anthropics/claude-code#77170; local record:' \
			'docs/upstream-reports/604-tray-panel-theme.md), retire the' \
			'patch. To unblock a security-bearing release while that' \
			'gets sorted, dropping patch_tray_icon_env_override from' \
			'active_patches is a legitimate stopgap — file the follow-up' \
			'issue.' >&2
		return 1
	fi
	echo '##############################################################'
}
