#!/usr/bin/env bash
set -euo pipefail
: "${TAG:?Release tag required}"
: "${GITHUB_REPOSITORY:?GitHub repository required}"
: "${GNUPGHOME:?Isolated signing keyring required}"
readonly fingerprint=3850BB9A57DCFF37E6290B7989E083867161269D
actual=$(gpg --batch --with-colons --list-secret-keys "$fingerprint" | awk -F: '$1=="fpr" {print $10; exit}')
[[ $actual == "$fingerprint" ]] || { echo 'Wrong RPM signing key' >&2; exit 1; }
rpm --import fedora/RPM-GPG-KEY-claude-desktop-fedora
for package in dist/*.rpm; do
    rpmsign --define '_openpgp_sign gpg' --define "_openpgp_sign_id $fingerprint" --addsign "$package"
    rpmkeys --checksig "$package"
done
repo="$PWD/repository/fedora/44/x86_64"
mkdir -p "$repo"
cp dist/*.rpm "$repo/"
createrepo_c --no-database --baseurl "https://github.com/$GITHUB_REPOSITORY/releases/download/$TAG/" "$repo"
gpg --batch --yes --local-user "$fingerprint" --armor --detach-sign "$repo/repodata/repomd.xml"
gpg --verify "$repo/repodata/repomd.xml.asc" "$repo/repodata/repomd.xml"
# RPMs stay in the versioned release, not Git history.
rm -- "$repo"/*.rpm
cp fedora/RPM-GPG-KEY-claude-desktop-fedora repository/
printf '%s\n' "$TAG" > repository/repo-version.txt
(cd dist && sha256sum -- *.rpm *.AppImage claude-desktop.png install-appimage.py > SHA256SUMS)
