#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
top="$root/repo-package"
mkdir -p "$top"/{BUILD,RPMS,SOURCES,SPECS,SRPMS,tmp} "$root/dist"
cp "$root/fedora/claude-desktop-fedora.repo" "$root/fedora/RPM-GPG-KEY-claude-desktop-fedora" "$top/SOURCES/"
cat > "$top/SPECS/claude-desktop-fedora-repo.spec" <<'EOF'
Name: claude-desktop-fedora-repo
Version: 1
Release: 1
Summary: Signed Claude Desktop repository for Fedora 44
License: MIT
URL: https://github.com/fischinger3-lab/claude-desktop-fedora
BuildArch: noarch
Source0: claude-desktop-fedora.repo
Source1: RPM-GPG-KEY-claude-desktop-fedora
Requires: dnf5
%description
Repository configuration and public signing key for Claude Desktop on Fedora 44 x86_64.
Package signatures and repository metadata signatures are required.
%install
install -Dm644 %{SOURCE0} %{buildroot}/etc/yum.repos.d/claude-desktop-fedora.repo
install -Dm644 %{SOURCE1} %{buildroot}/etc/pki/rpm-gpg/RPM-GPG-KEY-claude-desktop-fedora
%files
%config(noreplace) /etc/yum.repos.d/claude-desktop-fedora.repo
/etc/pki/rpm-gpg/RPM-GPG-KEY-claude-desktop-fedora
EOF
rpmbuild --define "_topdir $top" --define "_tmppath $top/tmp" -bb "$top/SPECS/claude-desktop-fedora-repo.spec"
cp "$top/RPMS/noarch/claude-desktop-fedora-repo-1-1.noarch.rpm" "$root/dist/"
