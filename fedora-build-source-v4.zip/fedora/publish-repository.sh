#!/usr/bin/env bash
set -euo pipefail
: "${GH_TOKEN:?GitHub token required}"
: "${GITHUB_REPOSITORY:?GitHub repository required}"
: "${TAG:?Release tag required}"
source_tree="$PWD/repository"
gitdir=$(mktemp -d)
askpass=$(mktemp)
trap 'rm -rf "$gitdir"; rm -f "$askpass"' EXIT
cat > "$askpass" <<'EOF'
#!/usr/bin/env bash
case "$1" in
    *Username*) printf '%s\n' x-access-token ;;
    *) printf '%s\n' "$GH_TOKEN" ;;
esac
EOF
chmod 700 "$askpass"
export GIT_ASKPASS="$askpass" GIT_TERMINAL_PROMPT=0
git init "$gitdir"
git -C "$gitdir" config credential.helper ''
git -C "$gitdir" config user.name 'github-actions[bot]'
git -C "$gitdir" config user.email '41898282+github-actions[bot]@users.noreply.github.com'
git -C "$gitdir" remote add origin "https://github.com/$GITHUB_REPOSITORY.git"
set +e
git -C "$gitdir" ls-remote --exit-code --heads origin rpm-repository >/dev/null
status=$?
set -e
case "$status" in
    0) git -C "$gitdir" fetch --depth=1 origin rpm-repository
       git -C "$gitdir" checkout -b rpm-repository FETCH_HEAD ;;
    2) git -C "$gitdir" checkout --orphan rpm-repository ;;
    *) echo 'Could not inspect repository branch' >&2; exit "$status" ;;
esac
# Retain hashed metadata from earlier versions for clients with cached repomd.xml.
cp -a "$source_tree/." "$gitdir/"
git -C "$gitdir" add .
if ! git -C "$gitdir" diff --cached --quiet; then
    git -C "$gitdir" commit -m "Publish signed Fedora repository for $TAG"
    git -C "$gitdir" push origin HEAD:refs/heads/rpm-repository
fi
