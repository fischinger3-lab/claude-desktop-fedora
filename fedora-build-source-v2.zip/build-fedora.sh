#!/usr/bin/env bash
# Fedora entry point: prepare once, create RPM + AppImage, collect artifacts.
set -euo pipefail
project_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$project_dir"
umask 022
export npm_config_cache="${npm_config_cache:-$project_dir/.cache/npm}"
mkdir -p "$npm_config_cache" dist
# Remove only previous package artifacts so a failed build cannot look successful.
rm -f dist/claude-desktop-unofficial-*.rpm dist/claude-desktop-unofficial-*.AppImage dist/SHA256SUMS
bash build.sh --build both --clean yes "$@"
shopt -s nullglob
artifacts=(claude-desktop-unofficial-*.rpm claude-desktop-unofficial-*.AppImage)
(( ${#artifacts[@]} == 2 )) || { echo 'Expected exactly one RPM and one AppImage' >&2; exit 1; }
mv -- "${artifacts[@]}" dist/
(cd dist && sha256sum -- *.rpm *.AppImage > SHA256SUMS)
printf 'RPM und AppImage erstellt: %s/dist\n' "$project_dir"
