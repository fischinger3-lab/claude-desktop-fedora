import unittest
from update import newest_package


def entry(version='3.6556.2', **changes):
    fields = dict(Package='claude-desktop', Architecture='amd64', Version=version,
                  Filename=f'pool/main/c/claude-desktop/claude-desktop_{version}_amd64.deb',
                  SHA256='a' * 64, Size='100')
    fields.update(changes)
    return '\n'.join(f'{key}: {value}' for key, value in fields.items())


class ResolverTests(unittest.TestCase):
    def test_numeric_order(self):
        self.assertEqual(newest_package(entry('3.9.0')+'\n\n'+entry('3.10.0'))[1], '3.10.0')

    def test_no_package(self):
        with self.assertRaises(ValueError): newest_package(entry(Architecture='arm64'))

    def test_foreign_path(self):
        with self.assertRaises(ValueError): newest_package(entry(Filename='https://evil.invalid/app.deb'))

    def test_invalid_checksum(self):
        with self.assertRaises(ValueError): newest_package(entry(SHA256='missing'))

    def test_unexpected_version(self):
        with self.assertRaises(ValueError): newest_package(entry(Version='3.0;echo bad'))

    def test_filename_mismatch(self):
        with self.assertRaises(ValueError): newest_package(entry(Version='3.0.0'))

    def test_invalid_size(self):
        with self.assertRaises(ValueError): newest_package(entry(Size='-1'))


if __name__ == '__main__': unittest.main()
