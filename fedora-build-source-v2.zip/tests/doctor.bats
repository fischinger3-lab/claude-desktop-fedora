#!/usr/bin/env bats
#
# doctor.bats
# Tests for diagnostic helpers in scripts/doctor.sh
#

SCRIPT_DIR="$(cd "$(dirname "${BATS_TEST_FILENAME}")" && pwd)"

load 'test_helper'

setup() {
	TEST_TMP=$(mktemp -d)
	export TEST_TMP

	export HOME="$TEST_TMP/home"
	export XDG_CACHE_HOME="$TEST_TMP/cache"
	export XDG_CONFIG_HOME="$TEST_TMP/config"
	mkdir -p "$HOME" "$XDG_CACHE_HOME" "$XDG_CONFIG_HOME"

	# Clear all input/display vars to avoid host-state leakage
	unset DISPLAY
	unset WAYLAND_DISPLAY
	unset XDG_SESSION_TYPE
	unset XDG_CURRENT_DESKTOP
	unset CLAUDE_USE_WAYLAND
	unset GTK_IM_MODULE
	unset CLAUDE_GTK_IM_MODULE
	unset CLAUDE_PASSWORD_STORE
	unset CLAUDE_TRAY_USE_DARK_ICON
	unset _DOCTOR_SECRET_BACKEND
	unset _DOCTOR_USERNS_PATH
	unset _DOCTOR_DEB_ELECTRON
	unset _DOCTOR_AA_PROFILE
	unset _DOCTOR_AA_LOADED
	# Keep the host's /usr/libexec/qemu-kvm (EL) out of the QEMU check.
	export _DOCTOR_QEMU_KVM="$TEST_TMP/no-qemu-kvm"

	# shellcheck source=scripts/doctor.sh
	source "$SCRIPT_DIR/../scripts/doctor.sh"

	_doctor_colors
	_doctor_failures=0

	# Default _pkg_installed to "unknown" (rc=2) so tests don't have
	# to stub it unless they're exercising the package-check branch.
	# Override in-test for rc=0 (installed) or rc=1 (missing).
	_pkg_installed() { return 2; }
}

teardown() {
	_kill_stand_ins
	if [[ -n "$TEST_TMP" && -d "$TEST_TMP" ]]; then
		rm -rf "$TEST_TMP"
	fi
}

# Make `command -v gtk-query-immodules-3.0` report "not found" so the
# immodules cache check is skipped. Used by tests that aren't
# exercising the cache branch but reach it because no earlier gate
# fires. `command -v` finds bash functions too, so just unsetting a
# stub function isn't enough — we shadow `command` itself.
_skip_gtk_query() {
	command() {
		if [[ $1 == '-v' && $2 == 'gtk-query-immodules-3.0' ]]; then
			return 1
		fi
		builtin command "$@"
	}
}

# =============================================================================
# _cowork_pkg_hint: ibus-gtk3 mapping (#550)
# =============================================================================

@test "_cowork_pkg_hint: debian maps ibus-gtk3 to ibus-gtk3 via apt" {
	local result
	result=$(_cowork_pkg_hint debian ibus-gtk3)
	[[ $result == "sudo apt install ibus-gtk3" ]]
}

@test "_cowork_pkg_hint: fedora maps ibus-gtk3 to ibus-gtk3 via dnf" {
	local result
	result=$(_cowork_pkg_hint fedora ibus-gtk3)
	[[ $result == "sudo dnf install ibus-gtk3" ]]
}

@test "_cowork_pkg_hint: arch maps ibus-gtk3 to ibus (bundled)" {
	local result
	result=$(_cowork_pkg_hint arch ibus-gtk3)
	[[ $result == "sudo pacman -S ibus" ]]
}

# =============================================================================
# _doctor_check_im_modules: CLAUDE_GTK_IM_MODULE override visibility
# =============================================================================

@test "_doctor_check_im_modules: emits override line when CLAUDE_GTK_IM_MODULE set" {
	# CLAUDE_GTK_IM_MODULE makes active_im non-empty, so we'd reach
	# the cache check — skip it to keep this test focused.
	_skip_gtk_query

	CLAUDE_GTK_IM_MODULE='xim'
	run _doctor_check_im_modules debian
	[[ $output == *'CLAUDE_GTK_IM_MODULE=xim'* ]]
	[[ $output == *'overrides GTK_IM_MODULE for Electron'* ]]
}

@test "_doctor_check_im_modules: no override line when CLAUDE_GTK_IM_MODULE unset" {
	run _doctor_check_im_modules debian
	[[ $output != *'CLAUDE_GTK_IM_MODULE'* ]]
}

# =============================================================================
# _doctor_check_im_modules: XWayland-with-IBus routing note
# =============================================================================

@test "_doctor_check_im_modules: emits XWayland note when wayland session and CLAUDE_USE_WAYLAND unset" {
	XDG_SESSION_TYPE='wayland'
	# CLAUDE_USE_WAYLAND deliberately unset
	run _doctor_check_im_modules debian
	[[ $output == *'XWayland'* ]]
	[[ $output == *'CLAUDE_USE_WAYLAND=1'* ]]
}

@test "_doctor_check_im_modules: XWayland note's tip does not claim native Wayland loses hotkeys" {
	XDG_SESSION_TYPE='wayland'
	unset CLAUDE_USE_WAYLAND
	run _doctor_check_im_modules debian
	[[ $output == *'global hotkey via portal on GNOME/KDE'* ]]
	[[ $output != *'loses global hotkeys'* ]]
}

@test "_doctor_check_im_modules: no XWayland note when CLAUDE_USE_WAYLAND=1" {
	XDG_SESSION_TYPE='wayland'
	CLAUDE_USE_WAYLAND='1'
	run _doctor_check_im_modules debian
	[[ $output != *'XWayland'* ]]
}

@test "_doctor_check_im_modules: no XWayland note on X11 session" {
	XDG_SESSION_TYPE='x11'
	run _doctor_check_im_modules debian
	[[ $output != *'XWayland'* ]]
}

# =============================================================================
# _doctor_check_im_modules: ibus-gtk3 package check
# =============================================================================

@test "_doctor_check_im_modules: warns when ibus selected but ibus-gtk3 missing" {
	# Package not installed (rc=1, definitive answer)
	_pkg_installed() { return 1; }

	GTK_IM_MODULE='ibus'
	run _doctor_check_im_modules debian
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'ibus-gtk3 is not installed'* ]]
	[[ $output == *'sudo apt install ibus-gtk3'* ]]
}

@test "_doctor_check_im_modules: no warning when ibus selected and ibus-gtk3 present" {
	# Package installed (rc=0); cache lists ibus.
	_pkg_installed() { return 0; }
	gtk-query-immodules-3.0() {
		echo '"ibus" "IBus" "ibus" "/usr/share/locale" "*"'
	}
	export -f gtk-query-immodules-3.0

	GTK_IM_MODULE='ibus'
	run _doctor_check_im_modules debian
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_im_modules: no package warning when active module isn't ibus" {
	# Even with rc=1 for ibus-gtk3, the package check should be
	# skipped entirely when GTK_IM_MODULE isn't ibus.
	_pkg_installed() { return 1; }
	_skip_gtk_query

	GTK_IM_MODULE='xim'
	run _doctor_check_im_modules debian
	[[ $output != *'ibus-gtk3'* ]]
}

@test "_doctor_check_im_modules: no package warning on unsupported distro (rc=2)" {
	# Default _pkg_installed (rc=2) — no warning even with ibus.
	_skip_gtk_query

	GTK_IM_MODULE='ibus'
	run _doctor_check_im_modules unknown
	[[ $output != *'[WARN]'* ]]
}

# =============================================================================
# _doctor_check_display_server
# =============================================================================

@test "_doctor_check_display_server: Wayland — PASS + desktop + XWayland default mode" {
	WAYLAND_DISPLAY='wayland-0'
	XDG_CURRENT_DESKTOP='GNOME'
	# CLAUDE_USE_WAYLAND unset → default XWayland mode
	run _doctor_check_display_server
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Display server: Wayland'* ]]
	[[ $output == *'Desktop: GNOME'* ]]
	[[ $output == *'XWayland'* ]]
}

@test "_doctor_check_display_server: native-Wayland tip names the portal, not a hotkey loss" {
	# Since #690 native Wayland keeps the global hotkey on GNOME/KDE via
	# the GlobalShortcuts portal; the old tip said it "disables global
	# hotkeys", steering GNOME users away from the fix (#862).
	WAYLAND_DISPLAY='wayland-0'
	XDG_CURRENT_DESKTOP='GNOME'
	run _doctor_check_display_server
	[[ $output == *'GlobalShortcuts portal on GNOME/KDE'* ]]
	[[ $output == *'lost on wlroots'* ]]
	[[ $output != *'disables global hotkeys'* ]]
	[[ $output != *'for global hotkey support'* ]]
}

@test "_doctor_check_display_server: Wayland + CLAUDE_USE_WAYLAND=1 — native mode" {
	WAYLAND_DISPLAY='wayland-0'
	CLAUDE_USE_WAYLAND='1'
	run _doctor_check_display_server
	[[ $output == *'native Wayland'* ]]
	[[ $output != *'XWayland'* ]]
}

@test "_doctor_check_display_server: Wayland + CLAUDE_USE_WAYLAND=0 — XWayland mode" {
	# Set-but-not-1 must not read as "native": the tri-state's
	# force-XWayland value takes the same branch as unset.
	WAYLAND_DISPLAY='wayland-0'
	CLAUDE_USE_WAYLAND='0'
	run _doctor_check_display_server
	[[ $output == *'Mode: X11 via XWayland'* ]]
	[[ $output != *'Mode: native Wayland'* ]]
}

@test "_doctor_check_display_server: X11 — PASS" {
	DISPLAY=':0'
	# WAYLAND_DISPLAY unset (setup clears it)
	run _doctor_check_display_server
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Display server: X11'* ]]
}

@test "_doctor_check_display_server: Wayland wins when both set" {
	WAYLAND_DISPLAY='wayland-0'
	DISPLAY=':0'
	run _doctor_check_display_server
	[[ $output == *'Display server: Wayland'* ]]
	[[ $output != *'Display server: X11'* ]]
}

@test "_doctor_check_display_server: neither set — FAIL bumps _doctor_failures" {
	# setup() already unsets DISPLAY and WAYLAND_DISPLAY. Called
	# DIRECTLY (not via `run`, which subshells away the counter
	# mutation) so the _doctor_failures increment — the only thing
	# from this check feeding doctor's exit status — is assertable.
	_doctor_failures=0
	_doctor_check_display_server > "$TEST_TMP/out"
	[[ $_doctor_failures -eq 1 ]]
	grep -q '\[FAIL\]' "$TEST_TMP/out"
	grep -q 'No display server detected' "$TEST_TMP/out"
}

# =============================================================================
# _doctor_check_im_modules: immodules cache check
# =============================================================================

@test "_doctor_check_im_modules: warns when GTK_IM_MODULE not in immodules cache" {
	# gtk-query-immodules-3.0 lists xim but not fcitx
	gtk-query-immodules-3.0() {
		echo '"xim" "X Input Method" "gtk30" "/usr/share/locale" "*"'
	}
	export -f gtk-query-immodules-3.0

	GTK_IM_MODULE='fcitx'
	run _doctor_check_im_modules debian
	[[ $output == *'[WARN]'* ]]
	[[ $output == *"'fcitx' not listed"* ]]
	[[ $output == *'gtk-query-immodules-3.0 --update-cache'* ]]
}

@test "_doctor_check_im_modules: no warning when active module is in cache" {
	gtk-query-immodules-3.0() {
		echo '"xim" "X Input Method" "gtk30" "/usr/share/locale" "*"'
	}
	export -f gtk-query-immodules-3.0

	GTK_IM_MODULE='xim'
	run _doctor_check_im_modules debian
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_im_modules: skips cache check when gtk-query-immodules-3.0 missing" {
	_skip_gtk_query

	GTK_IM_MODULE='fcitx'
	run _doctor_check_im_modules debian
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'cache may be stale'* ]]
}

@test "_doctor_check_im_modules: CLAUDE_GTK_IM_MODULE takes precedence as active module" {
	# Cache lists xim but not ibus. CLAUDE_GTK_IM_MODULE=xim should
	# win over GTK_IM_MODULE=ibus, so no cache warning fires.
	gtk-query-immodules-3.0() {
		echo '"xim" "X Input Method" "gtk30" "/usr/share/locale" "*"'
	}
	export -f gtk-query-immodules-3.0

	GTK_IM_MODULE='ibus'
	CLAUDE_GTK_IM_MODULE='xim'
	run _doctor_check_im_modules debian
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_im_modules: no checks fire when no IM module selected" {
	# Neither GTK_IM_MODULE nor CLAUDE_GTK_IM_MODULE set — function
	# should return early before the package or cache checks.
	run _doctor_check_im_modules debian
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'ibus-gtk3'* ]]
}

# =============================================================================
# _doctor_check_recent_crashes: GPU FATAL crash counter (#583)
# =============================================================================

# Install a coredumpctl shim. $1 is the coredumpctl-list-style
# multi-line output to emit (header + entry rows). The shim records
# its argv in $TEST_TMP/coredumpctl.args so a test can pin the COMM
# match word: a bare non-path match is a COMM filter, and matching
# the wrong name silences the probe entirely (#861).
_install_coredumpctl_shim() {
	mkdir -p "$TEST_TMP/bin"
	cat > "$TEST_TMP/bin/coredumpctl" <<SHIM
#!/usr/bin/env bash
printf '%s\\n' "\$@" > "$TEST_TMP/coredumpctl.args"
cat <<'OUT'
$1
OUT
SHIM
	chmod +x "$TEST_TMP/bin/coredumpctl"
	export PATH="$TEST_TMP/bin:$PATH"
}

@test "_doctor_check_recent_crashes: matches COMM claude-desktop, not electron" {
	# The official ELF shipped since v3.0.0 is named claude-desktop, so
	# that is the comm systemd-coredump records. `list electron` (the
	# 2.x binary name) matched nothing on any 3.x install.
	_install_coredumpctl_shim 'TIME PID UID GID SIG COREFILE EXE SIZE'
	run _doctor_check_recent_crashes \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	[[ $status -eq 0 ]]
	local -a argv
	mapfile -t argv < "$TEST_TMP/coredumpctl.args"
	[[ ${argv[0]} == 'list' ]]
	[[ ${argv[1]} == 'claude-desktop' ]]
	[[ ${argv[*]} != *electron* ]]
}

@test "_doctor_check_recent_crashes: no coredumpctl on PATH — silent" {
	# Force coredumpctl off PATH so the helper short-circuits.
	# Restore PATH before returning so teardown's rm works.
	local saved_path="$PATH"
	export PATH="/no-such-dir-for-test"
	run _doctor_check_recent_crashes \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	export PATH="$saved_path"
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_recent_crashes: zero crashes — silent" {
	# Listing has the header line only, no entry rows.
	_install_coredumpctl_shim 'TIME PID UID GID SIG COREFILE EXE SIZE'
	run _doctor_check_recent_crashes \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_recent_crashes: 1 crash — info line, no warn" {
	_install_coredumpctl_shim 'TIME PID UID GID SIG COREFILE EXE SIZE
Wed 2026-05-06 08:00:21 EDT 130375 1000 1000 SIGTRAP present /usr/lib/claude-desktop-unofficial/claude-desktop 21.6M'
	run _doctor_check_recent_crashes \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	[[ $status -eq 0 ]]
	[[ $output == *'Recent Claude Desktop crashes: 1'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_recent_crashes: 3+ crashes — warn + #583 pointer" {
	_install_coredumpctl_shim 'TIME PID UID GID SIG COREFILE EXE SIZE
Wed 2026-05-06 08:00:21 EDT 130375 1000 1000 SIGTRAP present /usr/lib/claude-desktop-unofficial/claude-desktop 21.6M
Mon 2026-05-04 07:44:48 EDT 930532 1000 1000 SIGTRAP present /usr/lib/claude-desktop-unofficial/claude-desktop 22.8M
Sun 2026-05-03 14:34:10 EDT 567221 1000 1000 SIGTRAP present /usr/lib/claude-desktop-unofficial/claude-desktop 12.4M'
	run _doctor_check_recent_crashes \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'Recent Claude Desktop crashes: 3'* ]]
	[[ $output == *'CLAUDE_DISABLE_GPU=1'* ]]
	[[ $output == *'/issues/583'* ]]
}

@test "_doctor_check_recent_crashes: path mismatch falls back with footnote" {
	# Three crashes from a DIFFERENT claude-desktop binary: Anthropic's
	# official package installed side by side shares the comm. Caller
	# passes our path, which doesn't match — helper falls back to the
	# total count and adds the footnote so the user knows the count
	# may belong to the other install.
	_install_coredumpctl_shim 'TIME PID UID GID SIG COREFILE EXE SIZE
Wed 2026-05-06 09:00:00 EDT 200001 1000 1000 SIGSEGV present /usr/lib/claude-desktop/claude-desktop 30M
Wed 2026-05-05 09:00:00 EDT 200002 1000 1000 SIGSEGV present /usr/lib/claude-desktop/claude-desktop 30M
Wed 2026-05-04 09:00:00 EDT 200003 1000 1000 SIGSEGV present /usr/lib/claude-desktop/claude-desktop 30M'
	run _doctor_check_recent_crashes \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'may be from another Claude Desktop install'* ]]
}

@test "_doctor_check_recent_crashes: empty electron_path falls back" {
	_install_coredumpctl_shim 'TIME PID UID GID SIG COREFILE EXE SIZE
Wed 2026-05-06 08:00:21 EDT 130375 1000 1000 SIGTRAP present /usr/lib/claude-desktop-unofficial/claude-desktop 21.6M'
	# Caller didn't pass an electron_path — helper still counts and
	# emits the info line based on the unfiltered total.
	run _doctor_check_recent_crashes ''
	[[ $status -eq 0 ]]
	[[ $output == *'Recent Claude Desktop crashes: 1'* ]]
	[[ $output == *'may be from another Claude Desktop install'* ]]
}

# =============================================================================
# _doctor_check_filename_limit: NAME_MAX probe + eCryptfs hint (#590)
# =============================================================================

# Install a getconf shim that emits $1 on stdout. Empty $1 → shim exits 1
# so callers can test the "getconf failed" path.
_install_getconf_shim() {
	mkdir -p "$TEST_TMP/bin"
	local value="$1"
	if [[ -z $value ]]; then
		cat > "$TEST_TMP/bin/getconf" <<'SHIM'
#!/usr/bin/env bash
exit 1
SHIM
	else
		cat > "$TEST_TMP/bin/getconf" <<SHIM
#!/usr/bin/env bash
echo ${value}
SHIM
	fi
	chmod +x "$TEST_TMP/bin/getconf"
	export PATH="$TEST_TMP/bin:$PATH"
}

# Install a df shim that emits a single-column fstype listing matching
# the `df --output=fstype` shape the helper relies on. Empty $1 → shim
# exits 1 so callers can test the "df failed" path.
_install_df_shim() {
	mkdir -p "$TEST_TMP/bin"
	local fstype="$1"
	if [[ -z $fstype ]]; then
		cat > "$TEST_TMP/bin/df" <<'SHIM'
#!/usr/bin/env bash
exit 1
SHIM
	else
		cat > "$TEST_TMP/bin/df" <<SHIM
#!/usr/bin/env bash
cat <<'OUT'
Type
${fstype}
OUT
SHIM
	fi
	chmod +x "$TEST_TMP/bin/df"
	export PATH="$TEST_TMP/bin:$PATH"
}

@test "_doctor_check_filename_limit: silent when NAME_MAX >= 200" {
	_install_getconf_shim '255'
	run _doctor_check_filename_limit
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_filename_limit: warns when NAME_MAX < 200" {
	_install_getconf_shim '143'
	_install_df_shim 'ext4'
	run _doctor_check_filename_limit
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'NAME_MAX=143'* ]]
	[[ $output == *'#590'* ]]
	# Non-ecryptfs fs: no LUKS hint
	[[ $output != *'eCryptfs'* ]]
	[[ $output != *'LUKS'* ]]
}

@test "_doctor_check_filename_limit: eCryptfs adds LUKS workaround hint" {
	_install_getconf_shim '143'
	_install_df_shim 'ecryptfs'
	run _doctor_check_filename_limit
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'NAME_MAX=143'* ]]
	[[ $output == *'eCryptfs'* ]]
	[[ $output == *'LUKS'* ]]
}

@test "_doctor_check_filename_limit: silent on non-numeric getconf output" {
	_install_getconf_shim 'undefined'
	run _doctor_check_filename_limit
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_filename_limit: silent when getconf fails" {
	_install_getconf_shim ''
	run _doctor_check_filename_limit
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_filename_limit: df failure suppresses eCryptfs hint, keeps warn" {
	_install_getconf_shim '143'
	_install_df_shim ''
	run _doctor_check_filename_limit
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'NAME_MAX=143'* ]]
	[[ $output != *'eCryptfs'* ]]
	[[ $output != *'LUKS'* ]]
}

# =============================================================================
# _doctor_check_password_store
#
# Since the v3.0.0 rebase the launcher no longer probes a keyring: the
# official build's os_crypt autodetect owns the decision, and
# CLAUDE_PASSWORD_STORE is the only knob. This is informational only —
# no PASS/FAIL.
# =============================================================================

@test "_doctor_check_password_store: unset reports upstream autodetect (no PASS/FAIL)" {
	# CLAUDE_PASSWORD_STORE unset by setup().
	run _doctor_check_password_store
	[[ $status -eq 0 ]]
	[[ $output == *'os_crypt autodetect'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_password_store: set reports the forced override (no PASS/FAIL)" {
	CLAUDE_PASSWORD_STORE='gnome-libsecret'
	run _doctor_check_password_store
	[[ $status -eq 0 ]]
	[[ $output == *'forced to gnome-libsecret'* ]]
	[[ $output == *'overrides upstream autodetection'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
}

# =============================================================================
# _doctor_check_tray_icon (#604)
#
# Informational only — no PASS/FAIL. The auto-detect verdict comes from
# the launcher's own setup_tray_icon_env (predicate parity); detection
# itself is pinned in launcher-common.bats, so these tests pin the
# reporting: preset wins, the helper's export is surfaced, and the
# standalone-source case (no launcher-common.sh) stays silent.
# =============================================================================

@test "_doctor_check_tray_icon: preset reports the forced value (no PASS/FAIL)" {
	CLAUDE_TRAY_USE_DARK_ICON=0
	run _doctor_check_tray_icon
	[[ $status -eq 0 ]]
	[[ $output == *'CLAUDE_TRAY_USE_DARK_ICON=0 (preset'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_tray_icon: non-0/1 preset draws a WARN" {
	CLAUDE_TRAY_USE_DARK_ICON=true
	run _doctor_check_tray_icon
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'not 0/1'* ]]
}

@test "_doctor_check_tray_icon: silent when launcher-common is not in scope" {
	# Standalone doctor.sh source: setup_tray_icon_env is undefined.
	run _doctor_check_tray_icon
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_tray_icon: reports Cinnamon auto-detect verdict" {
	setup_tray_icon_env() { export CLAUDE_TRAY_USE_DARK_ICON=1; }
	run _doctor_check_tray_icon
	[[ $status -eq 0 ]]
	[[ $output == *'Cinnamon dark panel auto-detected'* ]]
	[[ $output == *'TrayIconLinux-Dark.png'* ]]
}

@test "_doctor_check_tray_icon: reports upstream selection when auto-detect is a no-op" {
	setup_tray_icon_env() { :; }
	run _doctor_check_tray_icon
	[[ $status -eq 0 ]]
	[[ $output == *'upstream selection (no override)'* ]]
}

# =============================================================================
# _doctor_check_keyring_persistence (LD-3)
#
# Advisory data-at-rest warning for keyring-less sessions: without a
# reachable Secret Service / KWallet, os_crypt falls back to the
# plaintext 'basic' backend. Never a FAIL. Probe outcome forced via
# _DOCTOR_SECRET_BACKEND (present|absent).
# =============================================================================

@test "_doctor_check_keyring_persistence: reachable backend passes" {
	export _DOCTOR_SECRET_BACKEND='present'
	run _doctor_check_keyring_persistence
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'org.freedesktop.secrets'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'[FAIL]'* ]]
}

@test "_doctor_check_keyring_persistence: absent backend warns unencrypted-at-rest (advisory)" {
	export _DOCTOR_SECRET_BACKEND='absent'
	run _doctor_check_keyring_persistence
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'no Secret Service or KWallet'* ]]
	[[ $output == *'basic'* ]]
	[[ $output == *'unencrypted at rest'* ]]
	[[ $output != *'[FAIL]'* ]]
}

@test "_doctor_check_keyring_persistence: forced real backend skips the probe silently" {
	CLAUDE_PASSWORD_STORE='gnome-libsecret'
	export _DOCTOR_SECRET_BACKEND='absent'
	run _doctor_check_keyring_persistence
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_keyring_persistence: forced basic warns even with a backend present" {
	CLAUDE_PASSWORD_STORE='basic'
	export _DOCTOR_SECRET_BACKEND='present'
	run _doctor_check_keyring_persistence
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'CLAUDE_PASSWORD_STORE=basic'* ]]
	[[ $output == *'unencrypted at rest'* ]]
}

@test "_doctor_check_keyring_persistence: no session bus reports unable-to-probe info only" {
	# No hook: force the real probe down the rc=2 path by removing
	# every bus signal — no DBUS address, no $XDG_RUNTIME_DIR/bus
	# socket.
	unset DBUS_SESSION_BUS_ADDRESS
	export XDG_RUNTIME_DIR="$TEST_TMP/empty-runtime"
	mkdir -p "$XDG_RUNTIME_DIR"
	run _doctor_check_keyring_persistence
	[[ $status -eq 0 ]]
	[[ $output == *'unable to probe the session bus'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'[FAIL]'* ]]
}

@test "_secret_backend_reachable: kwallet name in the bus listing counts as reachable" {
	# Real probe path with a stubbed busctl: a KDE session where
	# only kwalletd6 (not Secret Service) is on the bus.
	export DBUS_SESSION_BUS_ADDRESS='unix:path=/dev/null'
	busctl() { printf 'org.kde.kwalletd6 123 - - - - -\n'; }
	run _secret_backend_reachable
	[[ $status -eq 0 ]]
	[[ $output == 'org.kde.kwalletd6' ]]
}

# =============================================================================
# _doctor_check_disk_space
# =============================================================================

@test "_doctor_check_disk_space: fails when under 100MB free" {
	df() { printf 'Avail\n50M\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'50MB free'* ]]
}

@test "_doctor_check_disk_space: warns when under 500MB free" {
	df() { printf 'Avail\n300M\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'300MB free'* ]]
}

@test "_doctor_check_disk_space: warns at exactly 100MB (tier boundary)" {
	# 100 is not < 100, so the FAIL tier must not fire; < 500 → WARN.
	df() { printf 'Avail\n100M\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $output == *'[WARN]'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output == *'100MB free'* ]]
}

@test "_doctor_check_disk_space: passes at exactly 500MB (tier boundary)" {
	# 500 is not < 500, so the WARN tier must not fire → PASS.
	df() { printf 'Avail\n500M\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $output == *'[PASS]'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output == *'500MB free'* ]]
}

@test "_doctor_check_disk_space: no false PASS on leading-zero df output" {
	# '0099' clears the numeric regex but would make (( )) parse the
	# value as octal and error out, falling through to the PASS
	# branch. The 10# normalization must read it as 99 → FAIL tier.
	df() { printf 'Avail\n0099M\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $output == *'[FAIL]'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output == *'99MB free'* ]]
}

@test "_doctor_check_disk_space: passes with ample free space" {
	df() { printf 'Avail\n2048M\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'2048MB free'* ]]
}

@test "_doctor_check_disk_space: no false PASS on non-numeric df output" {
	# A malformed/empty avail field must not slip through as a PASS,
	# and the skip must be visible rather than hiding behind a clean
	# summary.
	df() { printf 'Avail\nN/A\n'; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $status -eq 0 ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output == *'Disk space: unable to read (df)'* ]]
}

@test "_doctor_check_disk_space: visible skip when df is unavailable" {
	df() { return 127; }
	run _doctor_check_disk_space "$XDG_CONFIG_HOME"
	[[ $status -eq 0 ]]
	[[ $output == *'Disk space: unable to read (df)'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
}

# =============================================================================
# _doctor_check_singleton_lock
# =============================================================================

@test "_doctor_check_singleton_lock: no lock file present — PASS" {
	# XDG_CONFIG_HOME/Claude exists but has no SingletonLock.
	mkdir -p "$XDG_CONFIG_HOME/Claude"
	run _doctor_check_singleton_lock "$XDG_CONFIG_HOME/Claude"
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'no lock file'* ]]
}

# Pull the real launcher-common.sh into this test shell.
#
# The lock check delegates to _pid_is_claude_desktop, which lives in
# launcher-common.sh beside the other /proc/PID/exe readers. At runtime
# it is always in scope (launcher-common.sh sources doctor.sh), but
# this file sources doctor.sh standalone, so the SingletonLock tests
# source the real launcher-common.sh instead: a local stub would only
# mirror the prod call, and a `declare -F` fallback in doctor.sh would
# make these tests decoration.
_source_launcher_common() {
	# shellcheck source=scripts/launcher-common.sh
	source "$SCRIPT_DIR/../scripts/launcher-common.sh"
}

@test "_doctor_check_singleton_lock: symlink to a live Claude Desktop PID — PASS" {
	mkdir -p "$XDG_CONFIG_HOME/Claude"
	_source_launcher_common
	_spawn_claude_desktop_stand_in
	ln -s "myhost-$claude_pid" "$XDG_CONFIG_HOME/Claude/SingletonLock"
	run _doctor_check_singleton_lock "$XDG_CONFIG_HOME/Claude"
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'running process'* ]]
}

@test "_doctor_check_singleton_lock: symlink to a live PID that is not Claude Desktop — WARN, not PASS" {
	# #784: kill -0 alone false-PASSes a stale lock whose PID has
	# since been recycled by any other process of the same user.
	mkdir -p "$XDG_CONFIG_HOME/Claude"
	_source_launcher_common
	_spawn_plain_sleep
	ln -s "myhost-$plain_pid" "$XDG_CONFIG_HOME/Claude/SingletonLock"
	# Precondition: the PID really is signalable, so this test can
	# only pass via the executable check.
	kill -0 "$plain_pid"
	run _doctor_check_singleton_lock "$XDG_CONFIG_HOME/Claude"
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output == *'stale lock'* ]]
	[[ $output == *"PID $plain_pid is not a Claude Desktop process"* ]]
	[[ $output == *"Fix: rm '$XDG_CONFIG_HOME/Claude/SingletonLock'"* ]]
}

@test "_doctor_check_singleton_lock: symlink to a dead PID — WARN, not PASS" {
	mkdir -p "$XDG_CONFIG_HOME/Claude"
	# Spawn a process, capture its PID, wait for it to exit: that PID
	# is now provably dead (avoids a magic-number guess).
	bash -c 'exit 0' &
	local dead_pid=$!
	wait "$dead_pid" 2>/dev/null || true
	ln -s "myhost-$dead_pid" "$XDG_CONFIG_HOME/Claude/SingletonLock"
	run _doctor_check_singleton_lock "$XDG_CONFIG_HOME/Claude"
	[[ $output == *'[WARN]'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output == *'stale lock'* ]]
}

@test "_doctor_check_singleton_lock: regular file (not a symlink) — WARN, not a false PASS" {
	# Regression guard: an unclean update can leave a plain regular
	# file at SingletonLock. It still wedges the single-instance lock,
	# so it must not report '[PASS] no lock file'.
	mkdir -p "$XDG_CONFIG_HOME/Claude"
	printf '' > "$XDG_CONFIG_HOME/Claude/SingletonLock"
	run _doctor_check_singleton_lock "$XDG_CONFIG_HOME/Claude"
	[[ $output == *'[WARN]'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'no lock file'* ]]
	[[ $output == *'not a symlink'* ]]
}

# =============================================================================
# _doctor_check_cowork_daemon: orphaned fallback daemon (#882)
#
# Detection is the reaper's own _cowork_fallback_daemon_pids, so these
# source the real launcher-common.sh (see _source_launcher_common) and
# use real stand-ins with pgrep scoped to them. The UI is a real process
# too: stubbing the live-UI predicate hid #907, where the official
# app's main (no --class) counted as the daemon's parent. Scoping keeps
# a Claude Desktop running on the host out of every case.
# =============================================================================

@test "_doctor_check_cowork_daemon: silent when launcher-common is not in scope" {
	run _doctor_check_cowork_daemon
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_cowork_daemon: orphaned daemons warn with their PIDs space-separated" {
	_source_launcher_common
	_spawn_cowork_daemon_stand_in
	_spawn_cowork_daemon_stand_in
	_scope_pgrep_to_stand_ins
	run _doctor_check_cowork_daemon
	[[ $output == *'[WARN]'*'Cowork bwrap daemon: orphaned'* ]]
	# Either order: pgrep lists by PID, which only matches spawn order
	# until PIDs wrap.
	local a="${cowork_pids[0]}" b="${cowork_pids[1]}"
	[[ $output == *"(PIDs: $a $b)"* || $output == *"(PIDs: $b $a)"* ]]
}

@test "_doctor_check_cowork_daemon: daemon with our live UI passes" {
	_source_launcher_common
	_spawn_claude_main_stand_in "--class=$WM_CLASS"
	_spawn_cowork_daemon_stand_in
	_scope_pgrep_to_stand_ins
	run _doctor_check_cowork_daemon
	[[ $output == *'[PASS]'*'Cowork bwrap daemon: running (parent alive)'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_cowork_daemon: the official app is not the daemon's parent (#907)" {
	# Its main has no --class and it never spawns the fallback daemon.
	# It still holds the reapers off, so the advice is to quit it.
	_source_launcher_common
	_spawn_claude_main_stand_in
	_spawn_cowork_daemon_stand_in
	_scope_pgrep_to_stand_ins
	run _doctor_check_cowork_daemon
	[[ $output == *'[WARN]'*"Cowork bwrap daemon: orphaned (PIDs: $cowork_pid)"* ]]
	[[ $output == *'Fix: Quit the official Claude Desktop'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'Restart Claude Desktop'* ]]
}

@test "_doctor_check_cowork_daemon: a stopped UI of ours is not a parent (#907)" {
	_source_launcher_common
	_spawn_claude_main_stand_in "--class=$WM_CLASS"
	kill -STOP "$stand_in_pid"
	_spawn_cowork_daemon_stand_in
	_scope_pgrep_to_stand_ins
	run _doctor_check_cowork_daemon
	kill -CONT "$stand_in_pid"
	[[ $output == *'[WARN]'*'Cowork bwrap daemon: orphaned'* ]]
	[[ $output == *'Fix: Restart Claude Desktop'* ]]
	[[ $output != *'[PASS]'* ]]
}

@test "_doctor_check_cowork_daemon: a process naming the script is not reported (#882)" {
	# The doctor must report what the reaper would kill, and the reaper
	# spares this: no orphan WARN pointing users at a phantom daemon.
	_source_launcher_common
	_spawn_cowork_bystander_stand_in editor
	_scope_pgrep_to_stand_ins
	run _doctor_check_cowork_daemon
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

# =============================================================================
# _doctor_check_pkg_version: package-manager ownership (#711)
# =============================================================================

# Make `command -v` report the named package tools (rpm, dpkg-query)
# as missing so tests can simulate single-manager or tool-less hosts
# regardless of what the CI/dev box really has installed. Same shadow
# trick as _skip_gtk_query: `command -v` finds functions too, so
# shadowing `command` itself is the only reliable way.
_hide_pkg_tools() {
	_hidden_pkg_tools=" $* "
	command() {
		if [[ $1 == '-v' \
			&& $_hidden_pkg_tools == *" $2 "* ]]; then
			return 1
		fi
		builtin command "$@"
	}
}

@test "_doctor_check_pkg_version: rpm owns the path — rpm version wins over stale dpkg record (#711)" {
	# The #711 repro: Fedora host, rpm owns the install, but a stale
	# dpkg record from an old deb experiment still answers. The rpm
	# answer must win; the stale dpkg version must not appear at all.
	rpm() { printf '1.11847.5-2.0.19'; }
	dpkg-query() { printf '1.5354.0'; }

	run _doctor_check_pkg_version \
		'/usr/lib/claude-desktop-unofficial/claude-desktop'
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Installed version: 1.11847.5-2.0.19'* ]]
	[[ $output != *'1.5354.0'* ]]
}

@test "_doctor_check_pkg_version: dpkg-only host reports dpkg version" {
	_hide_pkg_tools rpm
	# -f='${db:Status-Status} ${Version}': status prefix first.
	dpkg-query() { printf 'installed 1.11847.5'; }

	run _doctor_check_pkg_version ''
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Installed version: 1.11847.5'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_pkg_version: dual-DB host where rpm does not own the path falls back to dpkg" {
	# rpm exists but the install is a real deb: `rpm -qf` says "not
	# owned" (rc=1, message on stdout) and dpkg must be consulted.
	rpm() {
		# $4 = probe path ($1=-qf $2=--qf $3=<format>)
		printf 'file %s is not owned by any package\n' "$4"
		return 1
	}
	dpkg-query() { printf 'installed 1.11847.5'; }

	run _doctor_check_pkg_version ''
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Installed version: 1.11847.5'* ]]
	[[ $output != *'not owned'* ]]
}

@test "_doctor_check_pkg_version: removed-but-not-purged dpkg record (rc state) warns, not PASS (#711 follow-up)" {
	# apt remove without --purge leaves a config-files (rc) record;
	# dpkg-query still answers a version for it. Must not PASS.
	_hide_pkg_tools rpm
	dpkg-query() { printf 'config-files 1.5354.0'; }

	run _doctor_check_pkg_version ''
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'AppImage'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'1.5354.0'* ]]
}

@test "_doctor_check_pkg_version: neither manager owns the install — warn (AppImage/Nix)" {
	rpm() { return 1; }
	dpkg-query() { return 1; }

	run _doctor_check_pkg_version ''
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'AppImage'* ]]
	[[ $output != *'[PASS]'* ]]
}

@test "_doctor_check_pkg_version: silent when no package tools exist" {
	_hide_pkg_tools rpm dpkg-query

	run _doctor_check_pkg_version ''
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

# Lay out the AppDir shape appimage.sh builds: the bundled desktop
# entry at the root, the Electron binary under usr/lib/claude-desktop.
# $1 = desktop entry body. Prints the electron path AppRun would pass.
_make_appdir() {
	local appdir="$BATS_TEST_TMPDIR/AppDir"
	mkdir -p "$appdir/usr/lib/claude-desktop"
	: > "$appdir/usr/lib/claude-desktop/claude-desktop"
	printf '%s\n' "$1" > "$appdir/com.anthropic.Claude.desktop"
	printf '%s\n' "$appdir/usr/lib/claude-desktop/claude-desktop"
}

@test "_doctor_check_pkg_version: AppImage reports its own version, not the host's deb" {
	# The host has an old deb installed; an AppImage run used to
	# report it as a [PASS] and feed it to the drift check.
	rpm() { return 1; }
	dpkg-query() { printf 'installed 1.52386.3-3.2.4'; }
	local app
	app=$(_make_appdir $'[Desktop Entry]\nName=Claude\nX-AppImage-Version=2.19675.1-3.3.5')

	run _doctor_check_pkg_version "$app" appimage
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS] Installed version: 2.19675.1-3.3.5 (AppImage)'* ]]
	[[ $output != *'1.52386.3'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_doctor_check_pkg_version: AppImage records its version for the drift check" {
	# Asserted in-shell, not via `run`: the subshell would discard the
	# _installed_pkg_version assignment the drift check reads.
	dpkg-query() { printf 'installed 1.52386.3-3.2.4'; }
	local app _installed_pkg_version=''
	app=$(_make_appdir $'[Desktop Entry]\nX-AppImage-Version=2.19675.1-3.3.5')

	_doctor_check_pkg_version "$app" appimage > /dev/null
	[[ $_installed_pkg_version == '2.19675.1-3.3.5' ]]

	_stub_curl_packages '2.19675.1'
	run _check_official_drift
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'in sync'* ]]
}

@test "run_doctor: passes the package type to _doctor_check_pkg_version" {
	# Structural pin: run_doctor runs every host check, so it is not
	# exercised end to end here. Without the second argument the
	# AppImage branch above is unreachable and the host's deb comes
	# back (the helper defaults to 'deb').
	run declare -f run_doctor
	[[ $output == *'_doctor_check_pkg_version "$electron_path" "$package_type"'* ]]
}

@test "_doctor_check_pkg_version: AppImage without a stamped version is info, never the host's deb" {
	dpkg-query() { printf 'installed 1.52386.3-3.2.4'; }
	local app _installed_pkg_version=''
	app=$(_make_appdir $'[Desktop Entry]\nName=Claude')

	_doctor_check_pkg_version "$app" appimage > /dev/null
	[[ -z $_installed_pkg_version ]]

	run _doctor_check_pkg_version "$app" appimage
	[[ $status -eq 0 ]]
	[[ $output == *'Installed version: unknown'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'1.52386.3'* ]]
}

# =============================================================================
# _check_legacy_env: 2.x knobs no longer honored (post-rebase)
# =============================================================================

@test "_check_legacy_env: silent when no legacy knobs are set" {
	unset CLAUDE_TITLEBAR_STYLE CLAUDE_MENU_BAR CLAUDE_KEEP_AWAKE \
		CLAUDE_QUIT_ON_CLOSE
	run _check_legacy_env
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_check_legacy_env: warns for each set legacy knob" {
	unset CLAUDE_MENU_BAR CLAUDE_KEEP_AWAKE CLAUDE_QUIT_ON_CLOSE
	CLAUDE_TITLEBAR_STYLE='hybrid'
	run _check_legacy_env
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'CLAUDE_TITLEBAR_STYLE'* ]]
	[[ $output == *'no longer honored'* ]]
	[[ $output != *'CLAUDE_MENU_BAR'* ]]
}

@test "_check_legacy_env: CLAUDE_QUIT_ON_CLOSE points at the tray toggle" {
	unset CLAUDE_TITLEBAR_STYLE CLAUDE_MENU_BAR CLAUDE_KEEP_AWAKE
	CLAUDE_QUIT_ON_CLOSE='1'
	run _check_legacy_env
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'CLAUDE_QUIT_ON_CLOSE'* ]]
	[[ $output == *'System Tray'* ]]
}

# =============================================================================
# _check_kvm: /dev/kvm presence + access (device path via _DOCTOR_KVM_DEV)
# =============================================================================

@test "_check_kvm: missing device warns that Cowork requires KVM" {
	export _DOCTOR_KVM_DEV="$TEST_TMP/no-such-kvm"
	run _check_kvm
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'Cowork requires KVM'* ]]
}

@test "_check_kvm: present and read-write passes" {
	export _DOCTOR_KVM_DEV="$TEST_TMP/kvm-rw"
	: > "$_DOCTOR_KVM_DEV"
	run _check_kvm
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'present and accessible'* ]]
}

@test "_check_kvm: present but not read-write warns with group hint" {
	# -r/-w are actual-access checks; root bypasses mode bits, so this
	# scenario is only meaningful for a non-root tester.
	[[ $EUID -eq 0 ]] && skip 'permission bits not enforced for root'
	export _DOCTOR_KVM_DEV="$TEST_TMP/kvm-ro"
	: > "$_DOCTOR_KVM_DEV"
	chmod 0000 "$_DOCTOR_KVM_DEV"
	run _check_kvm
	chmod 0644 "$_DOCTOR_KVM_DEV"
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'not read-write'* ]]
	[[ $output == *'usermod -aG kvm'* ]]
}

# =============================================================================
# _check_vhost_vsock: /dev/vhost-vsock (device path via _DOCTOR_VSOCK_DEV)
# =============================================================================

@test "_check_vhost_vsock: present passes" {
	export _DOCTOR_VSOCK_DEV="$TEST_TMP/vsock"
	: > "$_DOCTOR_VSOCK_DEV"
	run _check_vhost_vsock
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
}

@test "_check_vhost_vsock: absent warns with modprobe fix" {
	export _DOCTOR_VSOCK_DEV="$TEST_TMP/no-vsock"
	run _check_vhost_vsock
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'modprobe vhost_vsock'* ]]
	[[ $output == *'modules-load.d'* ]]
}

# =============================================================================
# _check_cowork_stack: firmware probe (paths via _DOCTOR_OVMF_PATHS)
# =============================================================================

@test "_check_cowork_stack: firmware found at an official probe path passes" {
	export _DOCTOR_OVMF_PATHS="$TEST_TMP/OVMF_CODE.fd"
	: > "$_DOCTOR_OVMF_PATHS"
	: > "$TEST_TMP/OVMF_VARS.fd"
	run _check_cowork_stack debian
	[[ $status -eq 0 ]]
	[[ $output == *"Firmware: $_DOCTOR_OVMF_PATHS"* ]]
	[[ $output != *'none of the client-probed paths'* ]]
	[[ $output != *'VARS template missing'* ]]
}

@test "_check_cowork_stack: CODE without its derived VARS file warns (#884)" {
	# The pre-#884 RPM link: OVMF_CODE_4M.fd exists, but the client's
	# derived OVMF_VARS_4M.fd does not (EL ships only OVMF_VARS.fd).
	export _DOCTOR_OVMF_PATHS="$TEST_TMP/OVMF_CODE_4M.fd"
	: > "$_DOCTOR_OVMF_PATHS"
	: > "$TEST_TMP/OVMF_VARS.fd"
	_cowork_incomplete=false
	_check_cowork_stack debian >/dev/null
	[[ $_cowork_incomplete == true ]]
	run _check_cowork_stack debian
	[[ $output == *"VARS template missing ($TEST_TMP/OVMF_VARS_4M.fd)"* ]]
}

@test "_check_cowork_stack: AAVMF CODE derives the AAVMF VARS path" {
	export _DOCTOR_OVMF_PATHS="$TEST_TMP/AAVMF_CODE.fd"
	: > "$_DOCTOR_OVMF_PATHS"
	run _check_cowork_stack debian
	[[ $output == *"VARS template missing ($TEST_TMP/AAVMF_VARS.fd)"* ]]
	: > "$TEST_TMP/AAVMF_VARS.fd"
	run _check_cowork_stack debian
	[[ $output != *'VARS template missing'* ]]
}

@test "_check_cowork_stack: firmware absent from probe list warns (distro-layout note)" {
	# A firmware file that exists elsewhere must NOT count — only the
	# client-probed paths do. Point the probe list at a nonexistent path.
	export _DOCTOR_OVMF_PATHS="$TEST_TMP/nope/OVMF_CODE.fd"
	run _check_cowork_stack debian
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'none of the client-probed paths'* ]]
	[[ $output == *'openSUSE'* ]]
}

@test "_cowork_fw_probe_paths: x86_64 lists official paths, then edk2 (#884)" {
	run _cowork_fw_probe_paths x86_64
	[[ $output == '/usr/share/OVMF/OVMF_CODE_4M.fd:/usr/share/OVMF/OVMF_CODE.fd:/usr/share/edk2/x64/OVMF_CODE.4m.fd:/usr/share/edk2/ovmf/OVMF_CODE.fd' ]]
}

@test "_cowork_fw_probe_paths: aarch64 is the official AAVMF path only" {
	run _cowork_fw_probe_paths aarch64
	[[ $output == '/usr/share/AAVMF/AAVMF_CODE.fd' ]]
}

@test "_cowork_fw_probe_paths: edk2 tail matches what the asar patch appends" {
	# Doctor must report the paths the patched client probes, no more and
	# no fewer. Read the patch's list straight from its source.
	local patch="$BATS_TEST_DIRNAME/../scripts/patches/cowork-firmware-probe.sh"
	local appended
	appended=$(sed -n '/^const extra = \[/,/^\];/p' "$patch" \
		| grep -oE "'/[^']+'" | tr -d "'" | paste -sd:)
	[[ -n $appended ]]
	run _cowork_fw_probe_paths x86_64
	[[ $output == "/usr/share/OVMF/OVMF_CODE_4M.fd:/usr/share/OVMF/OVMF_CODE.fd:$appended" ]]
}

@test "_check_cowork_stack: Arch edk2 layout pairs CODE with its VARS (#884)" {
	# Arch ships OVMF_CODE.4m.fd beside OVMF_VARS.4m.fd; the client's
	# replace("OVMF_CODE","OVMF_VARS") lands on the real file.
	mkdir -p "$TEST_TMP/edk2/x64"
	export _DOCTOR_OVMF_PATHS="$TEST_TMP/nope/OVMF_CODE.fd:$TEST_TMP/edk2/x64/OVMF_CODE.4m.fd"
	: > "$TEST_TMP/edk2/x64/OVMF_CODE.4m.fd"
	: > "$TEST_TMP/edk2/x64/OVMF_VARS.4m.fd"
	run _check_cowork_stack arch
	[[ $output == *"Firmware: $TEST_TMP/edk2/x64/OVMF_CODE.4m.fd"* ]]
	[[ $output != *'VARS template missing'* ]]
}

# =============================================================================
# _check_cowork_stack: QEMU binary (EL qemu-kvm via _DOCTOR_QEMU_KVM, #884)
# =============================================================================

# Make `command -v qemu-system-*` miss so the host's qemu can't leak in.
_hide_host_qemu() {
	command() {
		[[ $1 == '-v' && $2 == qemu-system-* ]] && return 1
		builtin command "$@"
	}
}

_stub_doctor_qemu_kvm() {
	printf '#!/bin/sh\nexit 0\n' > "$TEST_TMP/qemu-kvm"
	chmod +x "$TEST_TMP/qemu-kvm"
	export _DOCTOR_QEMU_KVM="$TEST_TMP/qemu-kvm"
	export _DOCTOR_OVMF_PATHS="$TEST_TMP/OVMF_CODE.fd"
	: > "$_DOCTOR_OVMF_PATHS"
}

# The link setup_cowork_qemu_path makes.
_doctor_qemu_shim() {
	printf '%s' "$XDG_CACHE_HOME/claude-desktop-debian/bin/qemu-system-x86_64"
}

# Assert directly, not via `run`: a `run` subshell would discard the
# _cowork_incomplete mutations the warning tests check.
@test "_check_cowork_stack: EL qemu-kvm passes and names the launcher shim" {
	uname() { echo x86_64; }
	_hide_host_qemu
	_stub_doctor_qemu_kvm
	mkdir -p "$(dirname "$(_doctor_qemu_shim)")"
	ln -s "$TEST_TMP/qemu-kvm" "$(_doctor_qemu_shim)"
	_check_cowork_stack centos > "$TEST_TMP/out"
	grep -qF "QEMU: $TEST_TMP/qemu-kvm (the launcher exposes it as" \
		"$TEST_TMP/out"
	run grep -q 'not found on PATH' "$TEST_TMP/out"
	[[ $status -ne 0 ]]
}

@test "_check_cowork_stack: EL qemu-kvm without the shim link warns" {
	uname() { echo x86_64; }
	_hide_host_qemu
	_stub_doctor_qemu_kvm
	_cowork_incomplete=false
	_check_cowork_stack centos > "$TEST_TMP/out"
	grep -qF "QEMU: $TEST_TMP/qemu-kvm found, but $(_doctor_qemu_shim) is missing or does not point at it" \
		"$TEST_TMP/out"
	grep -qF 'launch Claude Desktop once' "$TEST_TMP/out"
	run grep -q 'PASS.*QEMU' "$TEST_TMP/out"
	[[ $status -ne 0 ]]
	[[ $_cowork_incomplete == true ]]
}

@test "_check_cowork_stack: shim link pointing elsewhere warns" {
	uname() { echo x86_64; }
	_hide_host_qemu
	_stub_doctor_qemu_kvm
	mkdir -p "$(dirname "$(_doctor_qemu_shim)")"
	ln -s "$TEST_TMP/other-qemu" "$(_doctor_qemu_shim)"
	_cowork_incomplete=false
	_check_cowork_stack centos > "$TEST_TMP/out"
	grep -qF 'is missing or does not point at it' "$TEST_TMP/out"
	[[ $_cowork_incomplete == true ]]
}

@test "_check_cowork_stack: no qemu anywhere warns with the EL dnf hint" {
	_hide_host_qemu
	_cowork_incomplete=false
	_check_cowork_stack rocky > "$TEST_TMP/out"
	grep -q 'not found on PATH' "$TEST_TMP/out"
	grep -qF 'sudo dnf install qemu-kvm' "$TEST_TMP/out"
	[[ $_cowork_incomplete == true ]]
}

# =============================================================================
# _check_device_registry: ant-device-registry.json state (#780, path via
# _DOCTOR_DEVICE_REGISTRY). Diagnostic-only — INFO or silent, never
# WARN/FAIL, and must never flip _cowork_incomplete.
# =============================================================================

@test "_check_device_registry: absent file emits nothing" {
	export _DOCTOR_DEVICE_REGISTRY="$TEST_TMP/no-registry.json"
	run _check_device_registry "$TEST_TMP/config"
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_check_device_registry: none-only value reports the Linux upstream gap as INFO" {
	export _DOCTOR_DEVICE_REGISTRY="$TEST_TMP/registry.json"
	echo '{"acct":"none:123"}' > "$_DOCTOR_DEVICE_REGISTRY"
	run _check_device_registry "$TEST_TMP/config"
	[[ $status -eq 0 ]]
	[[ $output == *'not registered'* ]]
	[[ $output == *'#780'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_check_device_registry: pk1 value reports registered" {
	export _DOCTOR_DEVICE_REGISTRY="$TEST_TMP/registry.json"
	echo '{"acct":"pk1:deadbeef:rowpk"}' > "$_DOCTOR_DEVICE_REGISTRY"
	run _check_device_registry "$TEST_TMP/config"
	[[ $status -eq 0 ]]
	[[ $output == *'registered'* ]]
}

@test "_check_device_registry: never flips _cowork_incomplete" {
	# Call the helper directly (not via `run`) — `run` executes in a
	# subshell, so a flag mutation there is invisible to the test shell.
	export _DOCTOR_DEVICE_REGISTRY="$TEST_TMP/registry.json"
	echo '{"acct":"none:123"}' > "$_DOCTOR_DEVICE_REGISTRY"
	_cowork_incomplete=false
	_check_device_registry "$TEST_TMP/config" > "$TEST_TMP/out"
	[[ $_cowork_incomplete == false ]]
}

@test "_check_device_registry: mixed pk1+none prefers registered" {
	export _DOCTOR_DEVICE_REGISTRY="$TEST_TMP/registry.json"
	echo '{"acct1":"none:123","acct2":"pk1:deadbeef:rowpk"}' \
		> "$_DOCTOR_DEVICE_REGISTRY"
	run _check_device_registry "$TEST_TMP/config"
	[[ $status -eq 0 ]]
	[[ $output == *'registered'* ]]
	[[ $output != *'not registered'* ]]
}

# =============================================================================
# _check_official_drift: pool version comparison (curl stubbed)
# =============================================================================

# A curl stub emitting a one-stanza Packages index for a given pool
# version. The version is stashed in a global the stub reads at call
# time (avoids eval); args are ignored — tests don't exercise the URL.
_stub_curl_packages() {
	_STUB_PKG_VERSION="$1"
	curl() {
		cat <<PKGS
Package: claude-desktop
Version: $_STUB_PKG_VERSION
Filename: pool/main/c/claude-desktop/claude-desktop_${_STUB_PKG_VERSION}_amd64.deb
SHA256: deadbeefdeadbeef
Size: 123456
PKGS
	}
}

@test "_check_official_drift: skipped when curl is unavailable" {
	command() {
		if [[ $1 == '-v' && $2 == 'curl' ]]; then
			return 1
		fi
		builtin command "$@"
	}
	run _check_official_drift
	[[ $status -eq 0 ]]
	[[ $output == *'skipped'* ]]
	[[ $output == *'curl not available'* ]]
}

@test "_check_official_drift: offline (curl fails) is a skip, not a failure" {
	curl() { return 1; }
	_installed_pkg_version='1.17377.2-3.0.0'
	run _check_official_drift
	[[ $status -eq 0 ]]
	[[ $output == *'skipped'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'[PASS]'* ]]
}

@test "_check_official_drift: installed matches pool — PASS in sync" {
	_stub_curl_packages '1.17377.9'
	_installed_pkg_version='1.17377.9-3.0.0'
	run _check_official_drift
	[[ $status -eq 0 ]]
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'in sync'* ]]
	[[ $output == *'1.17377.9'* ]]
}

@test "_check_official_drift: installed behind pool — WARN with both versions" {
	_stub_curl_packages '1.17377.9'
	_installed_pkg_version='1.17000.0-3.0.0'
	run _check_official_drift
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'official pool has 1.17377.9'* ]]
	[[ $output == *'this install packages 1.17000.0'* ]]
}

@test "_check_official_drift: unknown installed version reports newest only" {
	_stub_curl_packages '1.17377.9'
	_installed_pkg_version=''
	run _check_official_drift
	[[ $status -eq 0 ]]
	[[ $output == *'1.17377.9'* ]]
	[[ $output == *'installed version unknown'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'[WARN]'* ]]
}

# =============================================================================
# _check_name_collision: classify an installed dpkg claude-desktop
# (official Anthropic package, or a pre-rename install of ours)
# (sources dir via _DOCTOR_APT_SOURCES_DIR; deb-family only)
# =============================================================================

# Stub dpkg-query answering the ${db:Status-Status}, ${Maintainer} and
# ${Version} probes for the package claude-desktop. $1 = maintainer,
# $2 = version, $3 = install status (default 'installed'); empty
# maintainer/version model "package not installed" (query fails), and
# the status probe fails the same way so a not-installed package also
# fails the caller's status gate.
_stub_dpkg_query() {
	_STUB_DPKG_MAINTAINER="$1"
	_STUB_DPKG_VERSION="$2"
	_STUB_DPKG_STATUS="${3:-installed}"
	dpkg-query() {
		case "$2" in
			*Status*)
				[[ -n $_STUB_DPKG_VERSION ]] || return 1
				printf '%s' "$_STUB_DPKG_STATUS"
				;;
			*Maintainer*)
				[[ -n $_STUB_DPKG_MAINTAINER ]] || return 1
				printf '%s' "$_STUB_DPKG_MAINTAINER"
				;;
			*Version*)
				[[ -n $_STUB_DPKG_VERSION ]] || return 1
				printf '%s' "$_STUB_DPKG_VERSION"
				;;
			*)
				return 1
				;;
		esac
	}
}

# Stub dpkg supporting only `--compare-versions A lt B`, via sort -V —
# the doctor host running these tests may not ship real dpkg.
_stub_dpkg_compare() {
	dpkg() {
		[[ $1 == '--compare-versions' && $3 == 'lt' ]] || return 2
		[[ $2 != "$4" ]] || return 1
		[[ $(printf '%s\n%s\n' "$2" "$4" | sort -V | head -1) \
			== "$2" ]]
	}
}

# Drop the official-repo fixture into the overridable sources dir.
_write_official_apt_source() {
	export _DOCTOR_APT_SOURCES_DIR="$TEST_TMP/sources.list.d"
	mkdir -p "$_DOCTOR_APT_SOURCES_DIR"
	cat > "$_DOCTOR_APT_SOURCES_DIR/claude-desktop.list" <<'LIST'
deb [signed-by=/usr/share/keyrings/claude.gpg] https://downloads.claude.ai/claude-desktop/apt/stable stable main
LIST
}

@test "_check_name_collision: silent when dpkg-query is absent" {
	command() {
		if [[ $1 == '-v' && $2 == 'dpkg-query' ]]; then
			return 1
		fi
		builtin command "$@"
	}
	export _DOCTOR_APT_SOURCES_DIR="$TEST_TMP/sources.list.d"
	mkdir -p "$_DOCTOR_APT_SOURCES_DIR"
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_check_name_collision: silent when no claude-desktop is installed (repo alone is fine)" {
	# Post-rename there is no same-name collision: Anthropic's repo
	# being configured is not by itself worth a message.
	_stub_dpkg_query '' ''
	_write_official_apt_source
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_check_name_collision: official install (Anthropic maintainer) — info, not warn" {
	_stub_dpkg_query 'Anthropic, PBC <support@anthropic.com>' \
		'1.18286.0'
	export _DOCTOR_APT_SOURCES_DIR="$TEST_TMP/sources.list.d"
	mkdir -p "$_DOCTOR_APT_SOURCES_DIR"
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ $output == *"Anthropic's official claude-desktop"* ]]
	[[ $output == *'SingletonLock'* ]]
	[[ $output == *'only one can run at a time'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_check_name_collision: official install detected via apt source when maintainer probe is inconclusive" {
	# Maintainer string does not say Anthropic, but the version is
	# post-rename and their apt source is configured — classify as
	# the official package via the repo signal.
	_stub_dpkg_query 'Claude Desktop Team <noreply@example.com>' \
		'1.18286.0'
	_stub_dpkg_compare
	_write_official_apt_source
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ $output == *"Anthropic's official claude-desktop"* ]]
	[[ $output == *'SingletonLock'* ]]
	[[ $output != *'[WARN]'* ]]
}

@test "_check_name_collision: legacy pre-rename package warns with migration hint" {
	# Our old package kept the name claude-desktop and versions
	# << 1.16000; the rename to claude-desktop-unofficial means a
	# lingering install deserves a warn plus the migration path.
	_stub_dpkg_query 'aaddrick <aaddrick@gmail.com>' '1.11847.5'
	_stub_dpkg_compare
	export _DOCTOR_APT_SOURCES_DIR="$TEST_TMP/sources.list.d"
	mkdir -p "$_DOCTOR_APT_SOURCES_DIR"
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'pre-rename'* ]]
	[[ $output == *'1.11847.5'* ]]
	[[ $output == *'sudo apt install claude-desktop-unofficial'* ]]
}

@test "_check_name_collision: removed-but-not-purged pre-rename record (config-files) stays silent (#711 follow-up)" {
	# apt remove without --purge leaves a config-files (rc) record for
	# a pre-rename claude-desktop; dpkg-query still answers Maintainer
	# and Version for it. Must not warn about software no longer
	# installed.
	_stub_dpkg_query 'aaddrick <aaddrick@gmail.com>' '1.11847.5' \
		'config-files'
	_stub_dpkg_compare
	export _DOCTOR_APT_SOURCES_DIR="$TEST_TMP/sources.list.d"
	mkdir -p "$_DOCTOR_APT_SOURCES_DIR"
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ -z $output ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'pre-rename'* ]]
}

@test "_check_name_collision: removed-but-not-purged transitional dummy (config-files, >=1.16000) with repo configured stays silent (#711 follow-up)" {
	# The transitional claude-desktop 1.16000.0 dummy autoremoved to rc
	# state post-migration: non-Anthropic maintainer + version
	# >= 1.16000 + repo configured would otherwise fall through to the
	# repo_found branch and report an install that is no longer there.
	_stub_dpkg_query 'Claude Desktop Team <noreply@example.com>' \
		'1.16000.0' 'config-files'
	_stub_dpkg_compare
	_write_official_apt_source
	run _check_name_collision
	[[ $status -eq 0 ]]
	[[ -z $output ]]
	[[ $output != *'Anthropic'* ]]
	[[ $output != *'[INFO]'* ]]
}

# =============================================================================
# _doctor_check_userns_apparmor
# =============================================================================

# Put the check into the "restriction in force + deb Electron present"
# state via the path hooks; tests then control the loaded-set / profile
# paths to drive the inner branches. The root-only EUID==0 variant of
# the present-on-disk INFO line is untested (suite runs non-root).
_userns_in_force() {
	printf '1\n' > "$TEST_TMP/userns"
	: > "$TEST_TMP/deb-electron"
	_DOCTOR_USERNS_PATH="$TEST_TMP/userns"
	_DOCTOR_DEB_ELECTRON="$TEST_TMP/deb-electron"
}

@test "_doctor_check_userns_apparmor: restriction not in force — silent" {
	printf '0\n' > "$TEST_TMP/userns"
	: > "$TEST_TMP/deb-electron"
	_DOCTOR_USERNS_PATH="$TEST_TMP/userns"
	_DOCTOR_DEB_ELECTRON="$TEST_TMP/deb-electron"
	run _doctor_check_userns_apparmor
	[[ $status -eq 0 ]]
	[[ -z $output ]]
}

@test "_doctor_check_userns_apparmor: in force but no deb Electron — silent" {
	printf '1\n' > "$TEST_TMP/userns"
	_DOCTOR_USERNS_PATH="$TEST_TMP/userns"
	_DOCTOR_DEB_ELECTRON="$TEST_TMP/no-deb-electron"
	run _doctor_check_userns_apparmor
	[[ -z $output ]]
}

@test "_doctor_check_userns_apparmor: profile loaded — PASS" {
	_userns_in_force
	printf 'claude-desktop-unofficial (enforce)\nfirefox (enforce)\n' \
		> "$TEST_TMP/loaded"
	_DOCTOR_AA_LOADED="$TEST_TMP/loaded"
	run _doctor_check_userns_apparmor
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'profile loaded'* ]]
}

@test "_doctor_check_userns_apparmor: not loaded, profile on disk — WARN + load hint" {
	_userns_in_force
	# claude-desktop (unconfined) is the official package's profile —
	# the co-install near-miss the ^claude-desktop-unofficial anchor
	# exists to disambiguate. A loosened grep false-PASSes here.
	printf 'firefox (enforce)\nclaude-desktop (unconfined)\n' \
		> "$TEST_TMP/loaded"
	_DOCTOR_AA_LOADED="$TEST_TMP/loaded"
	: > "$TEST_TMP/profile"
	_DOCTOR_AA_PROFILE="$TEST_TMP/profile"
	run _doctor_check_userns_apparmor
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'Claude profile not loaded'* ]]
	[[ $output == *'apparmor_parser -r'* ]]
}

@test "_doctor_check_userns_apparmor: not loaded, profile absent — WARN + no-profile hint" {
	_userns_in_force
	# Same co-install near-miss: official profile loaded, ours absent.
	printf 'firefox (enforce)\nclaude-desktop (unconfined)\n' \
		> "$TEST_TMP/loaded"
	_DOCTOR_AA_LOADED="$TEST_TMP/loaded"
	_DOCTOR_AA_PROFILE="$TEST_TMP/no-profile"
	run _doctor_check_userns_apparmor
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'No profile found'* ]]
}

@test "_doctor_check_userns_apparmor: loaded set unreadable, profile on disk — INFO (not PASS)" {
	_userns_in_force
	# Nonexistent loaded path → cat yields empty → "present on disk"
	# branch (mirrors non-root / securityfs-unmounted hosts).
	_DOCTOR_AA_LOADED="$TEST_TMP/no-loaded"
	: > "$TEST_TMP/profile"
	_DOCTOR_AA_PROFILE="$TEST_TMP/profile"
	run _doctor_check_userns_apparmor
	[[ $output == *'present on disk'* ]]
	[[ $output != *'[PASS]'* ]]
}

@test "_doctor_check_userns_apparmor: restricted, no profile anywhere — WARN" {
	_userns_in_force
	_DOCTOR_AA_LOADED="$TEST_TMP/no-loaded"
	_DOCTOR_AA_PROFILE="$TEST_TMP/no-profile"
	run _doctor_check_userns_apparmor
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'no Claude profile found'* ]]
}

# =============================================================================
# _check_cowork_virtiofsd: mirror the client's probe, not "anywhere" (#771)
# =============================================================================

# The client resolves virtiofsd from two hardcoded paths plus the
# bundled resources copy (un-gated by the virtiofsd-probe patch). A
# binary anywhere else must WARN with the symlink fix, not PASS —
# the false PASS is the doctor-vs-app disagreement from #771.

_stub_vfsd() {
	# Create an executable stub at $1 (under TEST_TMP)
	mkdir -p "$(dirname "$1")"
	printf '#!/bin/sh\n' > "$1"
	chmod +x "$1"
}

@test "_check_cowork_virtiofsd: client-probed path passes" {
	_stub_vfsd "$TEST_TMP/usr/libexec/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/usr/libexec/virtiofsd"
	run _check_cowork_virtiofsd debian ''
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'client-probed path'* ]]
}

@test "_check_cowork_virtiofsd: bundled copy passes when no client path hits" {
	_stub_vfsd "$TEST_TMP/resources/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/nonexistent"
	export _COWORK_VFSD_PATHS="$TEST_TMP/nonexistent"
	run _check_cowork_virtiofsd debian "$TEST_TMP/resources"
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'bundled copy'* ]]
}

@test "_check_cowork_virtiofsd: binary at a non-probed path warns with symlink fix" {
	_stub_vfsd "$TEST_TMP/usr/lib/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/nonexistent"
	export _COWORK_VFSD_PATHS="$TEST_TMP/usr/lib/virtiofsd"
	run _check_cowork_virtiofsd arch ''
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'the client only'* ]]
	[[ $output == *"sudo ln -s $TEST_TMP/usr/lib/virtiofsd /usr/bin/virtiofsd"* ]]
}

@test "_check_cowork_virtiofsd: not found anywhere warns with package hint" {
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/nonexistent"
	export _COWORK_VFSD_PATHS="$TEST_TMP/nonexistent"
	run _check_cowork_virtiofsd arch ''
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'virtiofsd: not found'* ]]
	[[ $output == *'sudo pacman -S'* ]]
}

@test "_check_cowork_virtiofsd: client path needs only read access (R_OK, like the client)" {
	mkdir -p "$TEST_TMP/usr/libexec"
	printf 'x' > "$TEST_TMP/usr/libexec/virtiofsd"
	chmod 444 "$TEST_TMP/usr/libexec/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/usr/libexec/virtiofsd"
	run _check_cowork_virtiofsd debian ''
	[[ $output == *'[PASS]'* ]]
}

@test "_check_cowork_virtiofsd: client-probed path preferred over bundled copy" {
	_stub_vfsd "$TEST_TMP/usr/bin/virtiofsd"
	_stub_vfsd "$TEST_TMP/resources/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/usr/bin/virtiofsd"
	run _check_cowork_virtiofsd debian "$TEST_TMP/resources"
	[[ $output == *'client-probed path'* ]]
	[[ $output != *'bundled copy'* ]]
}

@test "_check_cowork_virtiofsd: bundled copy without exec bit does not pass (X_OK, like the client)" {
	# The client resolves the bundled copy with X_OK; a mode-stripped
	# resources/virtiofsd must fall through to WARN, not PASS.
	mkdir -p "$TEST_TMP/resources"
	printf 'x' > "$TEST_TMP/resources/virtiofsd"
	chmod 644 "$TEST_TMP/resources/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/nonexistent"
	export _COWORK_VFSD_PATHS="$TEST_TMP/nonexistent"
	run _check_cowork_virtiofsd debian "$TEST_TMP/resources"
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'virtiofsd: not found'* ]]
}

# The _cowork_incomplete flag feeds run_doctor's Cowork readiness
# summary. These tests call the helper DIRECTLY — `run` executes in a
# subshell, so a flag mutation there is invisible to the test shell
# and can never be asserted (output goes to a file to keep bats logs
# clean).

@test "_check_cowork_virtiofsd: PASS leaves _cowork_incomplete false" {
	_stub_vfsd "$TEST_TMP/usr/libexec/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/usr/libexec/virtiofsd"
	_cowork_incomplete=false
	_check_cowork_virtiofsd debian '' > "$TEST_TMP/out"
	[[ $_cowork_incomplete == false ]]
	grep -q 'client-probed path' "$TEST_TMP/out"
}

@test "_check_cowork_virtiofsd: non-probed-path WARN flips _cowork_incomplete" {
	_stub_vfsd "$TEST_TMP/usr/lib/virtiofsd"
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/nonexistent"
	export _COWORK_VFSD_PATHS="$TEST_TMP/usr/lib/virtiofsd"
	_cowork_incomplete=false
	_check_cowork_virtiofsd arch '' > "$TEST_TMP/out"
	[[ $_cowork_incomplete == true ]]
	grep -q 'the client only' "$TEST_TMP/out"
}

@test "_check_cowork_virtiofsd: not-found WARN flips _cowork_incomplete" {
	export _COWORK_VFSD_CLIENT_PATHS="$TEST_TMP/nonexistent"
	export _COWORK_VFSD_PATHS="$TEST_TMP/nonexistent"
	_cowork_incomplete=false
	_check_cowork_virtiofsd arch '' > "$TEST_TMP/out"
	[[ $_cowork_incomplete == true ]]
	grep -q 'virtiofsd: not found' "$TEST_TMP/out"
}

# =============================================================================
# cowork_node_has_features / _doctor_check_bwrap_node: bwrap runtime (#772)
# =============================================================================

# The bwrap daemon needs a node providing fs.statfsSync (18.15/16.19).
# The doctor probes the capability, not the version — 18.0-18.14 has
# major 18 but not the call.

# Executable node stub at $1 that reports version $2 but fails the
# capability probe (everything except --version exits 1).
_stub_versioned_node() {
	cat > "$1" <<-'SH'
		#!/bin/sh
		case "$1" in
			--version) echo v18.0.0 ;;
			*) exit 1 ;;
		esac
	SH
	chmod +x "$1"
}

@test "cowork_node_has_features: real node provides fs.statfsSync" {
	command -v node >/dev/null || skip 'node not installed'
	cowork_node_has_features "$(command -v node)"
}

@test "cowork_node_has_features: capability-less node is rejected" {
	_stub_versioned_node "$TEST_TMP/oldnode"
	! cowork_node_has_features "$TEST_TMP/oldnode"
}

@test "cowork_node_has_features: missing or non-executable path is rejected" {
	! cowork_node_has_features "$TEST_TMP/nonexistent"
	printf 'x' > "$TEST_TMP/notexec"
	! cowork_node_has_features "$TEST_TMP/notexec"
}

@test "_doctor_check_bwrap_node: capable node via COWORK_NODE_PATH passes" {
	command -v node >/dev/null || skip 'node not installed'
	export COWORK_NODE_PATH="$(command -v node)"
	run _doctor_check_bwrap_node ''
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'bwrap daemon runtime'* ]]
}

@test "_doctor_check_bwrap_node: node lacking statfsSync warns, never passes" {
	_stub_versioned_node "$TEST_TMP/oldnode"
	export COWORK_NODE_PATH="$TEST_TMP/oldnode"
	run _doctor_check_bwrap_node ''
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'lacks'* ]]
	[[ $output == *'fs.statfsSync'* ]]
	[[ $output != *'[PASS] bwrap daemon runtime'* ]]
}

@test "_doctor_check_bwrap_node: no node anywhere warns with install hint" {
	# Shadow `command` so -v node/nodejs both miss (_skip_gtk_query
	# pattern); COWORK_NODE_PATH must not leak in from the host env.
	command() {
		if [[ $1 == '-v' && ( $2 == 'node' || $2 == 'nodejs' ) ]]; then
			return 1
		fi
		builtin command "$@"
	}
	unset COWORK_NODE_PATH
	run _doctor_check_bwrap_node ''
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'no system node/nodejs'* ]]
	[[ $output == *'18.15'* ]]
}

@test "_doctor_check_bwrap_node: shipped daemon present passes" {
	command -v node >/dev/null || skip 'node not installed'
	export COWORK_NODE_PATH="$(command -v node)"
	mkdir -p "$TEST_TMP/resources"
	printf '// daemon\n' > "$TEST_TMP/resources/cowork-vm-service.js"
	run _doctor_check_bwrap_node "$TEST_TMP/resources"
	[[ $output == *'cowork-vm-service.js present'* ]]
}

@test "_doctor_check_bwrap_node: missing daemon warns with reinstall hint" {
	command -v node >/dev/null || skip 'node not installed'
	export COWORK_NODE_PATH="$(command -v node)"
	mkdir -p "$TEST_TMP/resources"
	run _doctor_check_bwrap_node "$TEST_TMP/resources"
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'cowork-vm-service.js missing'* ]]
	[[ $output == *'reinstall'* ]]
}

@test "_doctor_check_bwrap_node: WARN paths flip _cowork_incomplete" {
	# Direct call — `run` subshells would discard the flag mutation.
	export COWORK_NODE_PATH="$TEST_TMP/nonexistent"
	_cowork_incomplete=false
	_doctor_check_bwrap_node '' > "$TEST_TMP/out"
	[[ $_cowork_incomplete == true ]]
	grep -q 'no system node' "$TEST_TMP/out"
}

# =============================================================================
# _doctor_check_electron_binary
# =============================================================================

@test "_doctor_check_electron_binary: provided path with parsable version — PASS" {
	local bin="$TEST_TMP/electron"
	printf '#!/bin/sh\n' > "$bin"
	chmod +x "$bin"
	_electron_version() { echo '28.1.0'; }
	run _doctor_check_electron_binary "$bin"
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Electron: v28.1.0'* ]]
}

@test "_doctor_check_electron_binary: provided path, unparsable version — PASS (found)" {
	local bin="$TEST_TMP/electron"
	printf '#!/bin/sh\n' > "$bin"
	chmod +x "$bin"
	_electron_version() { echo 'unknown'; }
	run _doctor_check_electron_binary "$bin"
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'Electron: found at'* ]]
}

@test "_doctor_check_electron_binary: provided path missing — FAIL" {
	run _doctor_check_electron_binary "$TEST_TMP/nope/electron"
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'not found at'* ]]
	[[ $output == *'claude-desktop-unofficial'* ]]
}

@test "_doctor_check_electron_binary: no path, system electron on PATH — PASS (system)" {
	command() {
		if [[ $1 == '-v' && $2 == 'electron' ]]; then
			echo '/usr/bin/electron'
			return 0
		fi
		builtin command "$@"
	}
	_electron_version() { echo '28.1.0'; }
	run _doctor_check_electron_binary ''
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'(system)'* ]]
}

@test "_doctor_check_electron_binary: no path, no system electron — FAIL" {
	command() {
		if [[ $1 == '-v' && $2 == 'electron' ]]; then
			return 1
		fi
		builtin command "$@"
	}
	run _doctor_check_electron_binary ''
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'Electron binary not found'* ]]
}

# =============================================================================
# _doctor_check_chrome_sandbox
# =============================================================================

# Shadow `stat -c %a/%U` with controlled perms/owner via globals (no
# eval — see the bash style guide).
_stub_stat_perms=''
_stub_stat_owner=''
_stub_stat() {
	_stub_stat_perms="$1"
	_stub_stat_owner="$2"
	stat() {
		if [[ $2 == '%a' ]]; then
			echo "$_stub_stat_perms"
		else
			echo "$_stub_stat_owner"
		fi
	}
}

@test "_doctor_check_chrome_sandbox: 4755 + root — PASS" {
	# Neutralize the hardcoded deb path so the test is host-independent.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/no-deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	_stub_stat '4755' 'root'
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *'[PASS]'* ]]
	[[ $output == *'permissions OK'* ]]
}

@test "_doctor_check_chrome_sandbox: wrong perms — FAIL (real stat)" {
	# Deliberately NO stat stub: a real 0644 file exercises the actual
	# `stat -c '%a'/'%U'` invocation and its parse. The stub keys on
	# \$2 == '%a', so it would keep passing if the real call's flags
	# regressed (e.g. stat -c -> stat -f); real output can't.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/no-deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	chmod 0644 "$TEST_TMP/app/chrome-sandbox"
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'perms=644'* ]]
	[[ $output == *"owner=$(id -un)"* ]]
}

@test "_doctor_check_chrome_sandbox: wrong owner — FAIL" {
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/no-deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	_stub_stat '4755' 'nobody'
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'owner=nobody'* ]]
}

@test "_doctor_check_chrome_sandbox: no sandbox anywhere — WARN" {
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/no-deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	# No chrome-sandbox file created next to electron.
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *'[WARN]'* ]]
	[[ $output == *'not found'* ]]
}

@test "_doctor_check_chrome_sandbox: electron-adjacent sandbox wins when both exist (single report)" {
	# FLIPPED from #745's deb-path-wins expectation: this fix judges
	# ONLY the running binary's sandbox when an electron path is given,
	# so with both files present the electron-adjacent one is reported.
	# Still pins the single-report contract.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/deb-sandbox"
	: > "$TEST_TMP/deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	_stub_stat '4755' 'root'
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *"$TEST_TMP/app/chrome-sandbox"* ]]
	[[ $output != *"$TEST_TMP/deb-sandbox"* ]]
	[[ $(grep -c 'Chrome sandbox' <<< "$output") -eq 1 ]]
}

@test "_doctor_check_chrome_sandbox: deb path used when no electron path given" {
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/deb-sandbox"
	: > "$TEST_TMP/deb-sandbox"
	_stub_stat '4755' 'root'
	run _doctor_check_chrome_sandbox ''
	[[ $output == *'[PASS]'* ]]
	[[ $output == *"$TEST_TMP/deb-sandbox"* ]]
}

@test "_doctor_check_chrome_sandbox: ignores a stale deb sandbox when an electron path is given" {
	# Regression guard (#714-class false green): a valid deb sandbox
	# exists, but the running binary (electron_path) has none. The old
	# code validated the deb path and reported PASS for a sandbox that
	# is not in use. The deb path must be ignored entirely -> WARN,
	# never PASS.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/deb-sandbox"
	: > "$TEST_TMP/deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	# No chrome-sandbox next to electron.
	_stub_stat '4755' 'root'
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *'[WARN]'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *"$TEST_TMP/deb-sandbox"* ]]
}

@test "_doctor_check_chrome_sandbox: judges the electron-path sandbox, not the deb one, when both exist" {
	# Regression guard: the running binary's sandbox has the wrong perms
	# (0755) while a stale deb sandbox is fine (4755 root). The old code
	# checked the deb path first and PASSed; the electron-path sandbox
	# is the one that must be judged -> FAIL.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/deb-sandbox"
	: > "$TEST_TMP/deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	# Path-aware stub: electron's sandbox is bad, everything else good.
	stat() {
		if [[ $3 == "$TEST_TMP/app/chrome-sandbox" ]]; then
			if [[ $2 == '%a' ]]; then echo '0755'; else echo 'root'; fi
		else
			if [[ $2 == '%a' ]]; then echo '4755'; else echo 'root'; fi
		fi
	}
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron"
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'perms=0755'* ]]
	[[ $output != *'[PASS]'* ]]
}

@test "_doctor_check_chrome_sandbox: appimage package type — INFO, no stat, no FAIL" {
	# #785: the AppImage stages chrome-sandbox but its permission
	# normalization drops the setuid bit and the mount/extract dir is
	# owned by the running user, so the perms check always FAILed with
	# an unactionable `sudo chown root:root /tmp/.mount_.../` hint --
	# and it is moot anyway (the nosuid mount means the helper never
	# runs; Chromium uses the userns sandbox or --no-sandbox, #884).
	# A 0644 adjacent sandbox, the worst case, must still produce a
	# single _info line and no stat call at all.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/no-deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	chmod 0644 "$TEST_TMP/app/chrome-sandbox"
	# Tripwire: any stat call would print this and break the
	# assertions below, so the "no stat" half is enforced, not
	# decoration.
	stat() { echo 'STAT-WAS-CALLED'; }
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron" 'appimage'
	[[ $status -eq 0 ]]
	[[ $output != *'STAT-WAS-CALLED'* ]]
	[[ $output != *'[FAIL]'* ]]
	[[ $output != *'[WARN]'* ]]
	[[ $output != *'[PASS]'* ]]
	[[ $output != *'sudo chown'* ]]
	[[ $output == *'setuid helper not used'* ]]
	[[ $output == *'nosuid'* ]]
	[[ $(grep -c 'Chrome sandbox' <<< "$output") -eq 1 ]]
}

@test "_doctor_check_chrome_sandbox: deb type still judges perms (#785 gate is appimage-only)" {
	# Guards the gate's blast radius: the same bad 0644 sandbox must
	# still FAIL when the package type is deb.
	_DOCTOR_DEB_SANDBOX="$TEST_TMP/no-deb-sandbox"
	mkdir -p "$TEST_TMP/app"
	: > "$TEST_TMP/app/chrome-sandbox"
	chmod 0644 "$TEST_TMP/app/chrome-sandbox"
	run _doctor_check_chrome_sandbox "$TEST_TMP/app/electron" 'deb'
	[[ $output == *'[FAIL]'* ]]
	[[ $output == *'perms=644'* ]]
}
